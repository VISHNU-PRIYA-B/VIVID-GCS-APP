import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:isar/isar.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:share_plus/share_plus.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:vivid_mapping_sandbox/core/db/isar_service.dart';
import 'package:vivid_mapping_sandbox/core/models/task.dart';
import 'package:vivid_mapping_sandbox/modules/wiper-gcs/sections/telemetry.dart';
import 'package:vivid_mapping_sandbox/modules/wiper-gcs/widgets/camera_view.dart';
import 'package:vivid_mapping_sandbox/ui/app_theme.dart';
import 'package:vivid_mapping_sandbox/ui/gcs_sidebar.dart';
import 'package:vivid_mapping_sandbox/ui/gcs_widgets.dart';
// home screen
// import 'package:vivid_mapping_sandbox/modules/wiper-gcs/screens/home_screen.dart';


class WiperMainScreen extends StatefulWidget {
  final Task task;
  final bool isActive;

  const WiperMainScreen({
    super.key,
    required this.task,
    required this.isActive,
  });

  @override
  State<WiperMainScreen> createState() => _WiperMainScreenState();
}

class _WiperMainScreenState extends State<WiperMainScreen>
    with TickerProviderStateMixin {
  late TabController _tabCtrl;
  late final WiperTelemetry _telemetry;
  int _tab = 0;

  int _currentStrip = 0;
  int get _totalStrips => (_faceWidth / _robotCleaningWidth).floor();

  int _currentFace = 1;
  double _faceStartY = 0.0;

  double _faceWidth = 0.0;
  double _faceHeight = 0.0;

  int _upCount = 0;
  int _downCount = 0;

  // Track if bot has touched the top/bottom boundary to prevent multiple counts
  bool _isAtTop = false;
  bool _isAtBottom = true;

  Map<int, Map<int, Map<String, int>>> _faceStripCounts = {};
  Map<int, Map<String, double>> _faceSnapshot = {};

  late final FlutterTts _tts;
  bool _waterWarningPlayed = false;
  bool _batteryWarningPlayed = false;

  Timer? _autoSaveTimer;
  double _lastSavedWater = 0;
  double _lastSavedEnergy = 0;

  ui.Image? _botImage;
  List<Offset> _robotPath = [];
  double _currentX = 0.0;
  double _currentY = 0.0;
  final double _robotCleaningWidth = 0.9;

  DateTime? _sessionStart;

  @override
  void initState() {
    super.initState();
    _currentStrip = widget.task.currentStrip;
    _currentFace = widget.task.currentFace;

    _faceHeight = widget.task.buildingHeight > 0
        ? widget.task.buildingHeight
        : 50.0;
    int facesCount =
        widget.task.numberOfFaces != null && widget.task.numberOfFaces! > 0
        ? widget.task.numberOfFaces!
        : 1;
    _faceWidth = (widget.task.surfaceArea / (_faceHeight * facesCount)).clamp(
      1.0,
      double.infinity,
    );



    // DECODE PERSISTENT HISTORY FROM ISAR
    if (widget.task.mappingState.isNotEmpty &&
        widget.task.mappingState != "{}") {
      try {
        final Map<String, dynamic> state = jsonDecode(widget.task.mappingState);
        _upCount = state['upCount'] ?? 0;
        _downCount = state['downCount'] ?? 0;
        _currentX = state['currentX'] ?? 0.0;
        _currentY = state['currentY'] ?? _faceHeight;

        if (state['faceStripCounts'] != null) {
          final decodedFSC = Map<String, dynamic>.from(
            state['faceStripCounts'],
          );
          decodedFSC.forEach((faceStr, stripMap) {
            int faceId = int.parse(faceStr);
            _faceStripCounts[faceId] = {};
            Map<String, dynamic>.from(stripMap).forEach((stripStr, countMap) {
              _faceStripCounts[faceId]![int.parse(stripStr)] =
                  Map<String, int>.from(countMap);
            });
          });
        }
      } catch (e) {
        debugPrint("Error decoding mapping state: $e");
        _resetToBottom();
      }
    } else {
      _resetToBottom();
    }

    _initTabController();

    _telemetry = WiperTelemetry();
    _telemetry.addListener(_processOdometry);

    _tts = FlutterTts();
    _tts.setLanguage("en-US");
    _tts.setSpeechRate(0.5);

    if (widget.isActive) {
      _telemetry.initConnection();
      _sessionStart = DateTime.now();
      _autoSaveTimer = Timer.periodic(
        const Duration(seconds: 5),
        (_) => _saveTelemetryToTask(),
      );
    }

    const AssetImage('lib/assets/bot_image.png')
        .resolve(const ImageConfiguration())
        .addListener(
          ImageStreamListener((ImageInfo info, bool _) {
            if (mounted) setState(() => _botImage = info.image);
          }),
        );
  }

  void _resetToBottom() {
    // 1. Calculate strips
    final int totalS = (_faceWidth / _robotCleaningWidth).floor();
    final double stripWidth = totalS > 0 ? _faceWidth / totalS : _faceWidth;

    // 2. Put the bot exactly in the horizontal center of the face
    _currentX = (_currentStrip * stripWidth) + (stripWidth / 2);

    // 3. Put the bot at the exact bottom of the face (ground level)
    _currentY = _faceHeight; // Bot defaults to bottom center
    _faceStartY = _currentY;

    // 4. Update the visual path and default direction (moving UP from ground)
    _robotPath = [Offset(_currentX, _currentY)];
  }

  // void _processOdometry() {
  //   if (!widget.isActive) return;

  //   // SYNC WITH TELEMETRY ALTITUDE
  //   // Assuming telemetry.altitude is in meters from the ground.
  //   // So currentY (pixels from top) = totalHeight - altitude.
  //   double newY = (_faceHeight - _telemetry.altitude).clamp(0.0, _faceHeight);

  //   // Only redraw if the bot actually moved a noticeable amount
  //   if ((_currentY - newY).abs() > 0.1) {
  //     setState(() {
  //               // 👉 FIX 1: Calculate the exact distance moved in this specific tick
  //       double distanceMoved = (_currentY - newY).abs();
  //       _currentY = newY;
  //       _robotPath.add(Offset(_currentX, _currentY));
  //       //------------------------ Used for mock data -------------------------

  //       // ── NEW: DYNAMIC AREA CALCULATION ──
  //       double completedFacesArea = (_currentFace - 1) * _faceWidth * _faceHeight;
  //       double completedStripsArea = _currentStrip * _robotCleaningWidth * _faceHeight;
  //       double currentStripArea = (_faceStartY - _currentY).abs() * _robotCleaningWidth;
        
  //       // Multiply total square meters by 10.7639 to get square feet for the UI
  //       widget.task.areaCovered = (completedFacesArea + completedStripsArea + currentStripArea) * 10.7639;
  //       _telemetry.areaCleaned = widget.task.areaCovered;
       
  //       // ------------------------used for mock data=============================

  //       // COUNTER LOGIC
  //       if (_currentY <= 0.5 && !_isAtTop) {
  //         _isAtTop = true;
  //         _isAtBottom = false;
  //         _upCount++;
  //       } else if (_currentY >= (_faceHeight - 0.5) && !_isAtBottom) {
  //         _isAtBottom = true;
  //         _isAtTop = false;
  //         _downCount++;
  //       } else if (_currentY > 0.5 && _currentY < (_faceHeight - 0.5)) {
  //         _isAtTop = false;
  //         _isAtBottom = false;
  //       }
  //     });
  //   }
  // }

  void _processOdometry() {
    if (!widget.isActive) return;

    // SYNC WITH TELEMETRY ALTITUDE
    // Assuming telemetry.altitude is in meters from the ground.
    // So currentY (pixels from top) = totalHeight - altitude.
    double newY = (_faceHeight - _telemetry.altitude).clamp(0.0, _faceHeight);

    // Only redraw if the bot actually moved a noticeable amount
    if ((_currentY - newY).abs() > 0.1) {
      setState(() {
        // 👉 FIX 1: Calculate the exact distance moved in this specific tick
        double distanceMoved = (_currentY - newY).abs();
        
        _currentY = newY;
        _robotPath.add(Offset(_currentX, _currentY));

        //------------------------ Used for mock data -------------------------

        // ── NEW: DYNAMIC AREA CALCULATION (Accumulator) ──
        // Distance Climbed * Cleaning Width * SqFt Conversion
        // By using +=, the area strictly increases and NEVER decreases!
        widget.task.areaCovered += ((distanceMoved * 0.05) * _robotCleaningWidth) * 10.7639;
        
        // Keep your mock sync line so the Statistics tab charts it properly
        _telemetry.areaCleaned = widget.task.areaCovered;
       
        // ------------------------used for mock data=============================

        // COUNTER LOGIC
        if (_currentY <= 0.5 && !_isAtTop) {
          _isAtTop = true;
          _isAtBottom = false;
          _upCount++;
        } else if (_currentY >= (_faceHeight - 0.5) && !_isAtBottom) {
          _isAtBottom = true;
          _isAtTop = false;
          _downCount++;
        } else if (_currentY > 0.5 && _currentY < (_faceHeight - 0.5)) {
          _isAtTop = false;
          _isAtBottom = false;
        }
      });
    }
  }

  void _saveAndResetCounts() {
    _faceStripCounts[_currentFace] ??= {};
    _faceStripCounts[_currentFace]![_currentStrip] = {
      'up': _upCount,
      'down': _downCount,
    };
    _faceSnapshot[_currentFace] = {
      'strip': _currentStrip.toDouble(),
      'y': _currentY,
    };
    _upCount = 0;
    _downCount = 0;
  }

  void _restoreCounts(int face, int strip) {
    _upCount = _faceStripCounts[face]?[strip]?['up'] ?? 0;
    _downCount = _faceStripCounts[face]?[strip]?['down'] ?? 0;
  }

  String _faceName(int face) {
    switch (face) {
      case 1:
        return 'FACE-1';
      case 2:
        return 'FACE-2';
      case 3:
        return 'FACE-3';
      case 4:
        return 'FACE-4';
      default:
        return 'FACE $face';
    }
  }

  List<_Tab> get _currentTabs {
    var tabs = [
      // home screen
      // const _Tab('HOME', Icons.dashboard_outlined, Icons.dashboard_rounded),
      const _Tab(
        'TELEMETRY',
        Icons.analytics_outlined,
        Icons.analytics_rounded,
      ),
      const _Tab('VISION', Icons.videocam_outlined, Icons.videocam_rounded),
      const _Tab('MAPPING', Icons.map_outlined, Icons.map_rounded),
      const _Tab('STATISTICS', Icons.bar_chart_outlined, Icons.bar_chart_rounded,),
      const _Tab('CONFIG', Icons.tune_outlined, Icons.tune_rounded),
    ];

    if (widget.task.snapshots.isNotEmpty) {
      tabs.add(
        const _Tab(
          'SNAPS',
          Icons.photo_library_outlined,
          Icons.photo_library_rounded,
        ),
      );
    }
    if (widget.task.videos.isNotEmpty) {
      tabs.add(
        const _Tab(
          'VIDEOS',
          Icons.video_collection_outlined,
          Icons.video_collection_rounded,
        ),
      );
    }
    if (widget.task.alerts.isNotEmpty) {
      tabs.add(
        const _Tab(
          'ALERTS',
          Icons.warning_amber_outlined,
          Icons.warning_rounded,
        ),
      );
    }
    return tabs;
  }

  void _initTabController() {
    _tabCtrl = TabController(
      length: _currentTabs.length,
      vsync: this,
      initialIndex: _tab >= _currentTabs.length ? 0 : _tab,
    );
    _tabCtrl.addListener(() {
      if (_tabCtrl.indexIsChanging) return;
      setState(() => _tab = _tabCtrl.index);
    });
  }

  // void _refreshTabs() {
  //   setState(() {
  //     _tabCtrl.dispose();
  //     _initTabController();
  //   });
  // }

  // void _refreshTabs() {
  //   final oldCtrl = _tabCtrl;
  //   _initTabController();
  //   setState(() {});
  //   // Wait until the UI is completely finished rebuilding before deleting the old controller!
  //   WidgetsBinding.instance.addPostFrameCallback((_) {
  //     oldCtrl.dispose();
  //   });
  // }

  void _refreshTabs() {
    final oldCtrl = _tabCtrl;
    _initTabController();
    setState(() {});
    // Wait until the UI is completely finished rebuilding before deleting the old controller!
    WidgetsBinding.instance.addPostFrameCallback((_) {
      oldCtrl.dispose();
    });
  }

  // ENCODES HISTORY SO IT PERSISTS FOREVER
  String _buildMappingStateJson() {
    final Map<String, dynamic> fscStringMap = {};
    _faceStripCounts.forEach((faceKey, stripMap) {
      final Map<String, dynamic> sMap = {};
      stripMap.forEach((stripKey, counts) {
        sMap[stripKey.toString()] = counts;
      });
      fscStringMap[faceKey.toString()] = sMap;
    });

    return jsonEncode({
      'upCount': _upCount,
      'downCount': _downCount,
      'currentX': _currentX,
      'currentY': _currentY,
      'faceSnapshot': _faceSnapshot,
      'faceStripCounts': fscStringMap,
    });
  }

  void _saveTelemetryToTask() async {
    if (!widget.isActive) return;

    List<AlertLog> newAlerts = [];

    if (_telemetry.waterLevel < 10.0 && !_waterWarningPlayed) {
      _tts.speak("Warning. Water level is critically low.");
      newAlerts.add(
        AlertLog()
          ..timestamp = DateTime.now()
          ..message = "Water Level Critical (<5%)"
          ..type = "CRITICAL",
      );
      _waterWarningPlayed = true;
    }

    // 👉 NEW: TEMPORARY MOCK FOR WATER AND ENERGY
    // Simulate consumption while hardware sensors are disabled
    if (_telemetry.inMotion || _telemetry.pump || _telemetry.brush1) {             
      // Add 0.002 kWh every 5 seconds (approx 1.44 kWh / hour)
      _telemetry.energyConsumed += 0.002; 
      
      // Add 0.0055 Liters every 5 seconds (approx 4.0 Liters / hour)
      _telemetry.waterUsed += 0.0055; 
    }

    // if (_telemetry.batteryLevel < 10.0 && !_batteryWarningPlayed) {
    //   _tts.speak("Warning. Battery level low. Please return to base.");
    //   newAlerts.add(
    //     AlertLog()
    //       ..timestamp = DateTime.now()
    //       ..message = "Battery Low (<10%)"
    //       ..type = "WARNING",
    //   );
    //   _batteryWarningPlayed = true;
    // }

    double diffWater = _telemetry.waterUsed - _lastSavedWater;
    double diffEnergy = _telemetry.energyConsumed - _lastSavedEnergy;

    if (diffWater > 0 ||
        diffEnergy > 0 ||
        newAlerts.isNotEmpty ||
        _robotPath.isNotEmpty) {
      _lastSavedWater = _telemetry.waterUsed;
      _lastSavedEnergy = _telemetry.energyConsumed;

      final isar = IsarService.isar;
      await isar.writeTxn(() async {
        final latestTask = await isar.tasks.get(widget.task.id);
        if (latestTask != null) {
          latestTask.waterUsed = (latestTask.waterUsed) + diffWater;
          latestTask.energyConsumed = (latestTask.energyConsumed) + diffEnergy;
          
          // ---------------------coded during mock data testing--------------

          latestTask.areaCovered = widget.task.areaCovered;
          // fl chart - chart history
          final hoursElapsed = _sessionStart == null?0.0:DateTime.now().difference(_sessionStart!).inSeconds/3600.0;

          latestTask.areaHistoryPersisted = List.from(latestTask.areaHistoryPersisted)
          ..add(HistoryPointer()..hour = hoursElapsed..value = latestTask.areaCovered);
          latestTask.waterHistoryPersisted = List.from(latestTask.waterHistoryPersisted)
            ..add(HistoryPointer()..hour = hoursElapsed..value = latestTask.waterUsed);
          latestTask.energyHistoryPersisted = List.from(latestTask.energyHistoryPersisted)
            ..add(HistoryPointer()..hour = hoursElapsed..value = latestTask.energyConsumed);
        // ── END NEW ──

          // ---------------------coded during mock data  testing ----------- 

          latestTask.currentFace = _currentFace;
          latestTask.currentStrip = _currentStrip;
          latestTask.mappingState = _buildMappingStateJson();

          if (newAlerts.isNotEmpty) {
            latestTask.alerts = List.from(latestTask.alerts)..addAll(newAlerts);
          }
          latestTask.isSynced = false;
          await isar.tasks.put(latestTask);

          if (mounted) {
            setState(() {
              widget.task.waterUsed = latestTask.waterUsed;
              widget.task.energyConsumed = latestTask.energyConsumed;
              widget.task.alerts = latestTask.alerts;
              widget.task.areaHistoryPersisted = latestTask.areaHistoryPersisted;
              widget.task.waterHistoryPersisted = latestTask.waterHistoryPersisted;
              widget.task.energyHistoryPersisted = latestTask.energyHistoryPersisted;
            });
            if (newAlerts.isNotEmpty) _refreshTabs();
          }
        }
      });
    }
  }

  @override
  void dispose() {
    _autoSaveTimer?.cancel();
    _saveTelemetryToTask();
    _telemetry.removeListener(_processOdometry);
    _telemetry.disposeConnection();
    _telemetry.dispose();
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _stopMission() async {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Ending mission and saving telemetry...')),
    );
    try {
      _autoSaveTimer?.cancel();

      final isar = IsarService.isar;
      await isar.writeTxn(() async {
        final latestTask = await isar.tasks.get(widget.task.id);
        if (latestTask != null) {
          latestTask.sessionDate = DateTime.now();
          latestTask.status = "COMPLETED";
          latestTask.currentFace = _currentFace;
          latestTask.currentStrip = _currentStrip;
          latestTask.mappingState = _buildMappingStateJson();
          latestTask.isSynced = false;
          await isar.tasks.put(latestTask);
        }
      });

      _telemetry.disposeConnection();

      if (mounted) Navigator.pop(context);
    } catch (e) {
      debugPrint("Failed to save mission data: $e");
    }
  }

  List<SidebarItem> _sidebarItems(BuildContext ctx) => [
    SidebarItem(
      icon: Icons.water_drop_rounded,
      label: 'Task List',
      sublabel: 'Return',
      onTap: () => Navigator.pop(ctx),
    ),
    if (widget.isActive)
      SidebarItem(
        icon: Icons.stop_circle_outlined,
        label: 'End Mission',
        sublabel: 'Save & Exit',
        accent: AppTheme.red,
        onTap: _stopMission,
      ),
  ];

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width >= 600;

    return GcsScaffold(
      screenTitle: widget.task.buildingName ?? 'Unknown',
      screenCode: 'WIPER · #${widget.task.id.toString().padLeft(4, '0')}',
      accentColor: widget.isActive ? AppTheme.green : AppTheme.cyan,
      items: _sidebarItems(context),
      activeIndex: _tab,
      body: Column(
        children: [
          _TabStrip(
            tabs: _currentTabs,
            current: _tab,
            isWide: isWide,
            onTap: (i) {
              _tabCtrl.animateTo(i);
              setState(() => _tab = i);
            },
          ),
          Expanded(
            child: TabBarView(
              controller: _tabCtrl,
              physics: const BouncingScrollPhysics(),
              children: [
                // HomeScreen(task: widget.task, telemetry: _telemetry),
              
                TelemetrySection(
                  task: widget.task,
                  isWide: isWide,
                  telemetry: _telemetry,
                ),
                _VisionTab(
                  task: widget.task,
                  isWide: isWide,
                  onSnapshot: (path, time, camName, isIssue, issueDesc) async {
                    final isar = IsarService.isar;
                    await isar.writeTxn(() async {
                      final latestTask = await isar.tasks.get(widget.task.id);
                      if (latestTask != null) {
                        bool wasEmpty = latestTask.snapshots.isEmpty;
                        latestTask.snapshots = List.from(latestTask.snapshots)
                          ..add(
                            TaskSnapshot()
                              ..filePath = path
                              ..timestamp = time
                              ..cameraName = camName
                              ..isIssue = isIssue
                              ..issueDescription = issueDesc,
                          );
                        latestTask.isSynced = false;
                        await isar.tasks.put(latestTask);
                        if (mounted) {
                          setState(
                            () => widget.task.snapshots = latestTask.snapshots,
                          );
                          if (wasEmpty) _refreshTabs();
                        }
                      }
                    });
                  },
                  onVideoRecorded: (path, time, camName) async {
                    final isar = IsarService.isar;
                    await isar.writeTxn(() async {
                      final latestTask = await isar.tasks.get(widget.task.id);
                      if (latestTask != null) {
                        bool exists = latestTask.videos.any(
                          (v) => v.filePath == path,
                        );
                        if (!exists) {
                          bool wasEmpty = latestTask.videos.isEmpty;
                          latestTask.videos = List.from(latestTask.videos)
                            ..add(
                              TaskVideo()
                                ..filePath = path
                                ..timestamp = time
                                ..cameraName = camName,
                            );
                          latestTask.isSynced = false;
                          await isar.tasks.put(latestTask);
                          if (mounted) {
                            setState(
                              () => widget.task.videos = latestTask.videos,
                            );
                            if (wasEmpty) _refreshTabs();
                          }
                        }
                      }
                    });
                  },
                ),
                _MappingTab(
                  path: _robotPath,
                  faceWidth: _faceWidth,
                  faceHeight: _faceHeight,
                  currentFace: _currentFace,
                  totalFaces: widget.task.numberOfFaces ?? 1,
                  faceName: _faceName(_currentFace),
                  currentStrip: _currentStrip,
                  totalStrips: _totalStrips,
                  currentY: _currentY,
                  currentX: _currentX,
                  upCount: _upCount,
                  downCount: _downCount,
                  stripDirectionCounts: Map<int, Map<String, int>>.from(
                    _faceStripCounts[_currentFace] ?? {},
                  ),
                  botImage: _botImage,
                  task: widget.task,
                  onDimensionsChanged: (w, h) async {
                    setState(() {
                      _faceWidth = w;
                      _faceHeight = h;
                      _currentStrip = 0;
                      _currentFace = 1;
                      _faceStripCounts = {};
                      _faceSnapshot = {};
                      _upCount = 0;
                      _downCount = 0;
                      _resetToBottom();
                    });
                    final isar = IsarService.isar;
                    await isar.writeTxn(() async {
                      final latestTask = await isar.tasks.get(widget.task.id);
                      if (latestTask != null) {
                        latestTask.surfaceArea = widget.task.surfaceArea;
                        latestTask.buildingHeight = widget.task.buildingHeight;
                        latestTask.currentStrip = _currentStrip;
                        latestTask.currentFace = _currentFace;
                        latestTask.mappingState = _buildMappingStateJson();
                        await isar.tasks.put(latestTask);
                      }
                    });
                  },
                  onNextStretch: () async {
                    setState(() {
                      _faceStripCounts[_currentFace] ??= {};
                      _faceStripCounts[_currentFace]![_currentStrip] = {
                        'up': _upCount,
                        'down': _downCount,
                      };

                      final int totalS = (_faceWidth / _robotCleaningWidth)
                          .floor();
                      final double stripWidth = totalS > 0
                          ? _faceWidth / totalS
                          : _faceWidth;

                      _currentStrip++;
                      widget.task.currentStrip = _currentStrip;

                      if (_currentStrip >= totalS) {
                        if (_currentFace < (widget.task.numberOfFaces ?? 1)) {
                          _currentFace++;
                          _currentStrip = 0;
                          widget.task.currentFace = _currentFace;
                          widget.task.currentStrip = 0;
                          _restoreCounts(_currentFace, _currentStrip);
                          _resetToBottom();
                        } else {
                          _currentStrip = totalS > 0 ? totalS - 1 : 0;
                          showDialog(
                            context: context,
                            builder: (ctx) => AlertDialog(
                              backgroundColor: AppTheme.bgPanel,
                              title: Text(
                                'Mission Complete!',
                                style: TextStyle(color: AppTheme.green),
                              ),
                              content: Text(
                                'All faces and strips have been completed.',
                                style: TextStyle(color: AppTheme.textHi),
                              ),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.pop(ctx),
                                  child: Text(
                                    'OK',
                                    style: TextStyle(color: AppTheme.cyan),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }
                      } else {
                        _currentX =
                            (_currentStrip * stripWidth) + (stripWidth / 2);
                        _robotPath = [Offset(_currentX, _currentY)];
                        _restoreCounts(_currentFace, _currentStrip);
                      }
                    });
                    final isar = IsarService.isar;
                    await isar.writeTxn(() async {
                      final latestTask = await isar.tasks.get(widget.task.id);
                      if (latestTask != null) {
                        latestTask.currentStrip = _currentStrip;
                        latestTask.currentFace = _currentFace;
                        latestTask.mappingState = _buildMappingStateJson();
                        await isar.tasks.put(latestTask);
                      }
                    });
                  },
                  onPrevStretch: () async {
                    setState(() {
                      _faceStripCounts[_currentFace] ??= {};
                      _faceStripCounts[_currentFace]![_currentStrip] = {
                        'up': _upCount,
                        'down': _downCount,
                      };

                      if (_currentStrip > 0) {
                        _currentStrip--;
                        widget.task.currentStrip = _currentStrip;
                        final int totalS = (_faceWidth / _robotCleaningWidth)
                            .floor();
                        final double stripWidth = totalS > 0
                            ? _faceWidth / totalS
                            : _faceWidth;
                        _currentX =
                            (_currentStrip * stripWidth) + (stripWidth / 2);
                        _robotPath = [Offset(_currentX, _currentY)];
                        _restoreCounts(_currentFace, _currentStrip);
                      } else if (_currentFace > 1) {
                        _currentFace--;
                        widget.task.currentFace = _currentFace;
                        final int totalS = (_faceWidth / _robotCleaningWidth)
                            .floor();
                        final double stripWidth = totalS > 0
                            ? _faceWidth / totalS
                            : _faceWidth;
                        _currentStrip = totalS > 0 ? totalS - 1 : 0;
                        widget.task.currentStrip = _currentStrip;
                        _currentX =
                            (_currentStrip * stripWidth) + (stripWidth / 2);
                        _robotPath = [Offset(_currentX, _currentY)];

                        // --------coded during mock data testing--------------

                        _faceStartY = _currentY; 

                        // --------coded during mock data testing--------------
                        _restoreCounts(_currentFace, _currentStrip);
                      }
                    });
                    final isar = IsarService.isar;
                    await isar.writeTxn(() async {
                      final latestTask = await isar.tasks.get(widget.task.id);
                      if (latestTask != null) {
                        latestTask.currentStrip = _currentStrip;
                        latestTask.currentFace = _currentFace;
                        latestTask.mappingState = _buildMappingStateJson();
                        await isar.tasks.put(latestTask);
                      }
                    });
                  },
                  onNextFace: () async {
                    setState(() {
                      if (_currentFace < (widget.task.numberOfFaces ?? 1)) {
                        // 1. Save current face progress
                        _saveAndResetCounts();

                        // 2. Advance face
                        _currentFace++;
                        widget.task.currentFace = _currentFace;
                        _currentStrip = 0;

                        // 3. Reset bot to bottom-center of new face
                        _resetToBottom();
                        _restoreCounts(_currentFace, _currentStrip);
                        _robotPath = [Offset(_currentX, _currentY)];
                      }
                    });

                    // 4. Persistent Save
                    final isar = IsarService.isar;
                    await isar.writeTxn(() async {
                      final latestTask = await isar.tasks.get(widget.task.id);
                      if (latestTask != null) {
                        latestTask.currentStrip = _currentStrip;
                        latestTask.currentFace = _currentFace;
                        latestTask.mappingState =
                            _buildMappingStateJson(); // Saving the history
                        await isar.tasks.put(latestTask);
                      }
                    });
                  },

                  // onPrevFace: () async {
                  //   setState(() {
                  //     if (_currentFace > 1) {
                  //       _saveAndResetCounts();
                  //       _currentFace--;
                  //       widget.task.currentFace = _currentFace;
                  //       _currentStrip = 0;
                  //       _resetToBottom();
                  //       _restoreCounts(_currentFace, _currentStrip);
                  //       _robotPath = [];
                  //     }
                  //   });
                  //   final isar = IsarService.isar;
                  //   await isar.writeTxn(() async {
                  //     final latestTask = await isar.tasks.get(widget.task.id);
                  //     if (latestTask != null) {
                  //       latestTask.currentStrip = _currentStrip;
                  //       latestTask.currentFace = _currentFace;
                  //       latestTask.mappingState = _buildMappingStateJson();
                  //       await isar.tasks.put(latestTask);
                  //     }
                  //   });
                  // },
                  onPrevFace: () async {
                    setState(() {
                      if (_currentFace > 1) {
                        // 1. Save current state
                        _saveAndResetCounts();

                        // 2. Go back
                        _currentFace--;
                        widget.task.currentFace = _currentFace;

                        // 3. Restore last known position (X, Y, Strip) from the snapshot
                        final snap = _faceSnapshot[_currentFace];
                        if (snap != null) {
                          _currentStrip = snap['strip']!.toInt();
                          _currentY = snap['y']!;
                          final int totalS = (_faceWidth / _robotCleaningWidth)
                              .floor();
                          final double stripWidth = totalS > 0
                              ? _faceWidth / totalS
                              : _faceWidth;
                          _currentX =
                              (_currentStrip * stripWidth) + (stripWidth / 2);
                        } else {
                          // Fallback if no snapshot
                          _currentStrip = 0;
                          _resetToBottom();
                        }
                        _restoreCounts(_currentFace, _currentStrip);
                        _robotPath = [Offset(_currentX, _currentY)];

                        // -----------coded during mock data testing----------------

                        _faceStartY = _currentY;

                        // -----------coded during mock data testing----------------
                      }
                    });

                    final isar = IsarService.isar;
                    await isar.writeTxn(() async {
                      final latestTask = await isar.tasks.get(widget.task.id);
                      if (latestTask != null) {
                        latestTask.currentStrip = _currentStrip;
                        latestTask.currentFace = _currentFace;
                        latestTask.mappingState = _buildMappingStateJson();
                        await isar.tasks.put(latestTask);
                      }
                    });
                  },

                  // onNextFace: () async {
                  //   setState(() {
                  //     if (_currentFace < (widget.task.numberOfFaces ?? 1)) {
                  //       _saveAndResetCounts();
                  //       _currentFace++;
                  //       widget.task.currentFace = _currentFace;
                  //       _currentStrip = 0;
                  //       _resetToBottom();
                  //       _restoreCounts(_currentFace, _currentStrip);
                  //       _robotPath = [];
                  //     }
                  //   });
                  //   final isar = IsarService.isar;
                  //   await isar.writeTxn(() async {
                  //     final latestTask = await isar.tasks.get(widget.task.id);
                  //     if (latestTask != null) {
                  //       latestTask.currentStrip = _currentStrip;
                  //       latestTask.currentFace = _currentFace;
                  //       latestTask.mappingState = _buildMappingStateJson();
                  //       await isar.tasks.put(latestTask);
                  //     }
                  //   });
                  // },
                ),
                _StatisticsTab(
                  task: widget.task,
                  isWide: isWide,
                  telemetry: _telemetry,
                  isActive: widget.isActive,
                  lastSavedWater: _lastSavedWater,
                  trueAreaCleaned: widget.task.areaCovered,
                  lastSavedEnergy: _lastSavedEnergy,
                  // fl chart
                  lastSavedWaterFl: _lastSavedWater,
                  lastSavedAreaFl: widget.task.areaCovered,
                  lastSavedEnergyFl: _lastSavedEnergy,
            
                ),
 
                _ConfigTab(
                  task: widget.task,
                  onTaskUpdated: () => setState(() {}),
                ),
                if (widget.task.snapshots.isNotEmpty)
                  _SnapsTab(task: widget.task),
                if (widget.task.videos.isNotEmpty)
                  _VideosTab(task: widget.task),
                if (widget.task.alerts.isNotEmpty)
                  _AlertsTab(task: widget.task),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Tab {
  final String label;
  final IconData icon;
  final IconData activeIcon;
  const _Tab(this.label, this.icon, this.activeIcon);
}

class _TabStrip extends StatelessWidget {
  final List<_Tab> tabs;
  final int current;
  final bool isWide;
  final void Function(int) onTap;
  const _TabStrip({
    required this.tabs,
    required this.current,
    required this.isWide,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: isWide ? 48 : 52,
      color: AppTheme.bgPanel,
      child: Row(
        children: List.generate(tabs.length, (i) {
          final active = i == current;
          final t = tabs[i];
          return Expanded(
            child: GestureDetector(
              onTap: () => onTap(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                height: double.infinity,
                decoration: BoxDecoration(
                  color: active ? AppTheme.cyanFaint : Colors.transparent,
                  border: Border(
                    bottom: BorderSide(
                      color: active ? AppTheme.cyan : AppTheme.borderDim,
                      width: active ? 2 : 1,
                    ),
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      active ? t.activeIcon : t.icon,
                      size: 15,
                      color: active ? AppTheme.cyan : AppTheme.textLo,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      t.label,
                      style: GoogleFonts.jetBrainsMono(
                        fontSize: 8,
                        fontWeight: active ? FontWeight.w700 : FontWeight.w400,
                        color: active ? AppTheme.cyan : AppTheme.textLo,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _VisionTab extends StatefulWidget {
  final Task task;
  final bool isWide;
  final Function(String, DateTime, String, bool, String)? onSnapshot;
  final Function(String, DateTime, String)? onVideoRecorded;

  const _VisionTab({
    required this.task,
    required this.isWide,
    this.onSnapshot,
    this.onVideoRecorded,
  });

  @override
  State<_VisionTab> createState() => _VisionTabState();
}

class _VisionTabState extends State<_VisionTab>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final pad = AppTheme.screenPad(context);
    final h = MediaQuery.of(context).size.width >= 600 ? 300.0 : 200.0;
    final safeTaskName = widget.task.buildingName ?? 'Unknown_Task';

    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: pad, vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GcsSectionLabel('Live Feeds (RTSP)'),
          const SizedBox(height: 12),
          SizedBox(
            height: h,
            child: CameraView(
              label: 'CAMERA A',
              url: widget.task.cameraALink,
              taskName: safeTaskName,
              faceNumber: widget.task.currentFace,
              onSnapshot: widget.onSnapshot,
              onVideoRecorded: widget.onVideoRecorded,
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: h,
            child: CameraView(
              label: 'CAMERA B',
              url: widget.task.cameraBLink,
              taskName: safeTaskName,
              faceNumber: widget.task.currentFace,
              onSnapshot: widget.onSnapshot,
              onVideoRecorded: widget.onVideoRecorded,
            ),
          ),
        ],
      ),
    );
  }
}

class _StatisticsTab extends StatelessWidget {
  final Task task;
  final bool isWide;
  final bool isActive;
  final WiperTelemetry telemetry;
  final double lastSavedWater;
  final double trueAreaCleaned;
  final double lastSavedEnergy;
  // fl chart
  final double lastSavedWaterFl;
  final double lastSavedAreaFl;
  final double lastSavedEnergyFl;


  const _StatisticsTab({
    required this.task,
    required this.isWide,
    required this.telemetry,
    required this.isActive,
    required this.lastSavedWater,
    required this.trueAreaCleaned,
    required this.lastSavedEnergy,
    // fl chart
    required this.lastSavedWaterFl,
    required this.lastSavedAreaFl,
    required this.lastSavedEnergyFl,
  });

  // maxy value
  double _maxYFromValue(double displayedValue) => 
  displayedValue > 0 ? displayedValue : 1.0;


  @override
  Widget build(BuildContext context) {
    final pad = AppTheme.screenPad(context);

    return AnimatedBuilder(
      animation: telemetry,
      builder: (context, _) {
        // final t = telemetry;
        // double safeWater = task.waterUsed;
        // double safeEnergy = task.energyConsumed;
// maxy value
        final t = telemetry;

        final double waterValue = isActive
            ? task.waterUsed + (t.waterUsed - lastSavedWater)
            : task.waterUsed;
        final double energyValue = isActive
            ? task.energyConsumed + (t.energyConsumed - lastSavedEnergy)
            : task.energyConsumed;
        final double areaValue = trueAreaCleaned;

        Widget statsWrap = Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            // MicroTeleTile(
            //   label: 'WATER USED',
            //   value: isActive
            //       ? (safeWater + (t.waterUsed - lastSavedWater))
            //             .toStringAsFixed(1)
            //       : safeWater.toStringAsFixed(1),
            //   unit: 'L',
            //   icon: Icons.water_drop_outlined,
            //   color: AppTheme.cyan,
            // ),
            // MicroTeleTile(
            //   label: 'ENERGY CONSUMED',
            //   value: isActive
            //       ? (safeEnergy + (t.energyConsumed - lastSavedEnergy))
            //             .toStringAsFixed(1)
            //       : safeEnergy.toStringAsFixed(1),
            //   unit: 'kWh',
            //   icon: Icons.bolt_rounded,
            //   color: AppTheme.amber,
            // ),
            // MicroTeleTile(
            //   label: 'AREA CLEANED',
            //   value: trueAreaCleaned.toStringAsFixed(0),
            //   unit: 'sqft',
            //   icon: Icons.square_foot_rounded,
            //   color: AppTheme.green,
            // ),
            // maxy value
            MicroTeleTile(
              label: 'WATER USED',
              value: waterValue.toStringAsFixed(1),
              unit: 'L',
              icon: Icons.water_drop_outlined,
              color: AppTheme.cyan,
            ),
            MicroTeleTile(
              label: 'ENERGY CONSUMED',
              value: energyValue.toStringAsFixed(1),
              unit: 'kWh',
              icon: Icons.bolt_rounded,
              color: AppTheme.amber,
            ),
            MicroTeleTile(
              label: 'AREA CLEANED',
              value: areaValue.toStringAsFixed(0),
              unit: 'sqft',
              icon: Icons.square_foot_rounded,
              color: AppTheme.green,
            ),
          ],

        );

        Widget chartsColumn = Column(
          children: [
            _ChartCard(
              title: 'AREA CLEANED vs TIME (sqft / hr)',
              color: AppTheme.green,
              // maxY: 10000,
              // maxy value
              maxY: _maxYFromValue(areaValue),
              // fl chart
              spots: task.areaHistoryPersisted.map((p) => FlSpot(p.hour, p.value)).toList(),
            ),
            const SizedBox(height: 12),
            _ChartCard(
              title: 'WATER USED vs TIME (L / hr)',
              color: AppTheme.cyan,
              // maxY: 3000,
              // maxy Value
              maxY: _maxYFromValue(waterValue),
              // spots: t.waterHistory,
              spots: task.waterHistoryPersisted.map((p) => FlSpot(p.hour, p.value)).toList(),
            ),
            const SizedBox(height: 12),
            _ChartCard(
              title: 'ENERGY CONSUMED vs TIME (kWh / hr)',
              color: AppTheme.amber,
              // maxY: 1000,
              // maxy value
              maxY: _maxYFromValue(energyValue),
              // spots: t.energyHistory,
              spots: task.energyHistoryPersisted.map((p) => FlSpot(p.hour, p.value)).toList(),
            ),
          ],
        );

        return SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: pad, vertical: 16),
          child: isWide
              ? Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      flex: 2,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          GcsSectionLabel('Session Totals'),
                          const SizedBox(height: 12),
                          statsWrap,
                        ],
                      ),
                    ),
                    const SizedBox(width: 20),
                    Expanded(
                      flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          GcsSectionLabel('Performance Analytics'),
                          const SizedBox(height: 12),
                          chartsColumn,
                        ],
                      ),
                    ),
                  ],
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    GcsSectionLabel('Session Totals'),
                    const SizedBox(height: 12),
                    statsWrap,
                    const SizedBox(height: 24),
                    GcsSectionLabel('Performance Analytics'),
                    const SizedBox(height: 12),
                    chartsColumn,
                  ],
                ),
        );
      },
    );
  }
}

class _ChartCard extends StatelessWidget {
  final String title;
  final Color color;
  final double maxY;
  final List<FlSpot> spots;
  const _ChartCard({
    required this.title,
    required this.color,
    required this.maxY,
    required this.spots,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppTheme.borderDim),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.jetBrainsMono(
              fontSize: 9,
              color: AppTheme.textMid,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: LineChart(
              LineChartData(
                // gridData: FlGridData(
                //   show: true,
                //   drawVerticalLine: false,
                //   getDrawingHorizontalLine: (value) =>
                //       FlLine(color: AppTheme.borderDim, strokeWidth: 1),
                // ),
                // titlesData: FlTitlesData(
                //   leftTitles: AxisTitles(
                //     sideTitles: SideTitles(
                //       showTitles: true,
                //       reservedSize: 40,
                //       getTitlesWidget: (val, meta) => Text(
                //         val.toInt().toString(),
                //         style: GoogleFonts.jetBrainsMono(
                //           fontSize: 8,
                //           color: AppTheme.textLo,
                //         ),
                //       ),
                //     ),
                //   ),
                // maxy value
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: maxY / 2,          // grid lines at 0, 50%, 100%
                  getDrawingHorizontalLine: (value) =>
                      FlLine(color: AppTheme.borderDim, strokeWidth: 1),
                ),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 40,
                      interval: maxY / 2,                // labels at 0, 50%, 100%
                      getTitlesWidget: (val, meta) => Text(
                        maxY >= 100
                            ? val.round().toString()
                            : maxY >= 1
                                ? val.toStringAsFixed(1)
                                : val.toStringAsFixed(2),
                        style: GoogleFonts.jetBrainsMono(fontSize: 8, color: AppTheme.textLo),
                      ),
                    ),
                  ),
                  // bottomTitles, topTitles, rightTitles unchanged
                // ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 22,
                      interval:0.5,
                      // getTitlesWidget: (val, meta) => Text(
                      //   '${val.toInt()}h',
                      getTitlesWidget: (val, meta){
                        final isHalf = (val*10).round() % 10 !=0;
                        final hourPart = val.floor();
                        final label = isHalf ? '$hourPart.30' :'$hourPart';
                        return Text(label,
                        style: GoogleFonts.jetBrainsMono(
                          fontSize: 8,
                          color: AppTheme.textLo,           
                        ),
                        );
                      },
                      
                    ),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),
                borderData: FlBorderData(show: false),
                // maxy vale
                clipData: const FlClipData.all(),
                minX: 0,
                maxX: 7,
                minY: 0,
                maxY: maxY,
                lineBarsData: [
                  LineChartBarData(
                    // spots:  [
                    //   FlSpot(0, 0),
                    //   FlSpot(3, 0.2),
                    //   FlSpot(5, 0.4),
                    //   FlSpot(8, 0.7),
                    //   FlSpot(12, 0.9),
                    //   ].map((spot) => FlSpot(spot.x, spot.y * maxY)).toList(),
                    // fl chart
                    // spots: spots.isNotEmpty ? spots : const [FlSpot(0, 0)]
                    //     .map((spot) => FlSpot(spot.x, spot.y * maxY))
                    //     .toList(),
                    spots: spots.isNotEmpty ? spots : const [FlSpot(0, 0)],
                    isCurved: true,
                    color: color, 
                    barWidth: 2,
                    isStrokeCapRound: true,
                    dotData: const FlDotData(show: false),
                    belowBarData: BarAreaData(
                      show: true,
                      color: color.withOpacity(0.1),
  
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MappingTab extends StatelessWidget {
  final List<Offset> path;
  final double faceWidth;
  final double faceHeight;
  final int currentFace;
  final int totalFaces;
  final String faceName;
  final int currentStrip;
  final int totalStrips;
  final double currentY;
  final double currentX;
  final Task task;
  final VoidCallback onNextStretch;
  final VoidCallback onPrevStretch;
  final VoidCallback onNextFace;
  final VoidCallback onPrevFace;
  final Function(double, double) onDimensionsChanged;
  final int upCount;
  final int downCount;

  final Map<int, Map<String, int>> stripDirectionCounts;
  final ui.Image? botImage;

  const _MappingTab({
    required this.path,
    required this.faceWidth,
    required this.faceHeight,
    required this.currentFace,
    required this.totalFaces,
    required this.faceName,
    required this.currentStrip,
    required this.totalStrips,
    required this.currentY,
    required this.currentX,
    required this.task,
    required this.onNextStretch,
    required this.onPrevStretch,
    required this.onNextFace,
    required this.onPrevFace,
    required this.onDimensionsChanged,
    required this.upCount,
    required this.downCount,
    required this.stripDirectionCounts,
    required this.botImage,

  });

  double _faceProgress() {
    if (totalStrips <= 0) return 0;
    return (currentStrip / totalStrips * 100).clamp(0, 100);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 👉 NEW COMPACT HEADER (No manual up/down arrows, no text on stretch buttons)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppTheme.borderDim),
            ),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  GcsSectionLabel('Trajectory'),
                  const SizedBox(width: 12),

                  _FaceInputButton(
                    faceName: faceName,
                    currentFace: currentFace,
                    totalFaces: totalFaces,
                    faceProgress: _faceProgress(),
                    faceWidth: faceWidth,
                    faceHeight: faceHeight,
                    onDimensionsChanged: onDimensionsChanged,
                    onPrevFace: onPrevFace,
                    onNextFace: onNextFace,
                  ),

                  const SizedBox(width: 8),

                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: AppTheme.amber.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      'STRIP ${currentStrip + 1}/$totalStrips',
                      style: GoogleFonts.jetBrainsMono(
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.amber,
                      ),
                    ),
                  ),

                  const SizedBox(width: 16),

                  Text(
                    '↑$upCount ↓$downCount',
                    style: GoogleFonts.jetBrainsMono(
                      color: AppTheme.green,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),

                  const SizedBox(width: 16),

                  IconButton(
                    icon: const Icon(
                      Icons.arrow_back_ios_rounded,
                      size: 20,
                      // color: Colors.white,
                      color: const Color(0xFF1ABECC),
                    ),
                    onPressed: onPrevStretch,
                    tooltip: "Previous Stretch",
                    constraints: const BoxConstraints(),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 6,
                    ),
                  ),

                  IconButton(
                    icon: const Icon(
                      Icons.arrow_forward_ios_rounded,
                      size: 20,
                      color: const Color(0xFF1ABECC),
                    ),
                    onPressed: onNextStretch,
                    tooltip: "Next Stretch",
                    constraints: const BoxConstraints(),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 6,
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 12),

          Expanded(
            child: Column(
              children: [
                Expanded(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Container(
                        width: 28,
                        alignment: Alignment.center,
                        child: RotatedBox(
                          quarterTurns: 3,
                          child: Text(
                            'height: ${faceHeight.toStringAsFixed(0)}m',
                            style: GoogleFonts.jetBrainsMono(
                              fontSize: 11,
                              color: AppTheme.cyan,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: LayoutBuilder(
                          builder: (context, constraints) {
                            final size = Size(
                              constraints.maxWidth,
                              constraints.maxHeight,
                            );

                            final altitude = faceHeight - currentY;
                            final pct = (altitude / faceHeight * 100).clamp(
                              0.0,
                              100.0,
                            );
                            final widthCoveredPct = (currentX / faceWidth * 100)
                                .clamp(0.0, 100.0);
                            final widthRemaining = (faceWidth - currentX).clamp(
                              0.0,
                              faceWidth,
                            );

                            // Canvas is scrollable horizontally with fixed 50px strip width
                            final double fixedStripWidthPx = 50.0;
                            final double canvasWidth = max(
                              size.width,
                              totalStrips * fixedStripWidthPx,
                            );

                            return Stack(
                              children: [
                                Container(
                                  width: double.infinity,
                                  height: double.infinity,
                                  decoration: BoxDecoration(
                                    color: AppTheme.bgCard,
                                    border: Border.all(
                                      color: AppTheme.borderDim,
                                    ),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: ClipRect(
                                    child: SingleChildScrollView(
                                      scrollDirection: Axis.horizontal,
                                      child: SizedBox(
                                        width: canvasWidth,
                                        height: size.height,
                                        child: CustomPaint(
                                          painter: _RobotPathPainter(
                                            points: path,
                                            faceWidth: faceWidth,
                                            faceHeight: faceHeight,
                                            currentStrip: currentStrip,
                                            totalStrips: totalStrips,
                                            currentY: currentY,
                                            stripWidthPx: fixedStripWidthPx,
                                            stripDirectionCounts:
                                                stripDirectionCounts,
                                            upCount: upCount,
                                            downCount: downCount,
                                            botImage: botImage,
                                          ),
                                          size: Size(canvasWidth, size.height),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),

                                Positioned(
                                  top: 16,
                                  right: 16,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 12,
                                      vertical: 10,
                                    ),
                                    decoration: BoxDecoration(
                                      color: AppTheme.bgCard.withOpacity(0.9),
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                        color: AppTheme.cyan.withOpacity(0.6),
                                      ),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Row(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  'ALTITUDE',
                                                  style:
                                                      GoogleFonts.jetBrainsMono(
                                                        fontSize: 9,
                                                        color: AppTheme.textMid,
                                                        letterSpacing: 1.2,
                                                      ),
                                                ),
                                                const SizedBox(height: 4),
                                                Row(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment
                                                          .baseline,
                                                  textBaseline:
                                                      TextBaseline.alphabetic,
                                                  children: [
                                                    Text(
                                                      altitude.toStringAsFixed(
                                                        1,
                                                      ),
                                                      style:
                                                          GoogleFonts.jetBrainsMono(
                                                            fontSize: 22,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            color:
                                                                AppTheme.amber,
                                                          ),
                                                    ),
                                                    const SizedBox(width: 4),
                                                    Text(
                                                      'm',
                                                      style:
                                                          GoogleFonts.jetBrainsMono(
                                                            fontSize: 11,
                                                            color: AppTheme
                                                                .textMid,
                                                          ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                            Container(
                                              width: 1,
                                              height: 48,
                                              color: AppTheme.cyan.withOpacity(
                                                0.3,
                                              ),
                                              margin:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 12,
                                                  ),
                                            ),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  'WIDTH',
                                                  style:
                                                      GoogleFonts.jetBrainsMono(
                                                        fontSize: 9,
                                                        color: AppTheme.textMid,
                                                        letterSpacing: 1.2,
                                                      ),
                                                ),
                                                const SizedBox(height: 4),
                                                Row(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment
                                                          .baseline,
                                                  textBaseline:
                                                      TextBaseline.alphabetic,
                                                  children: [
                                                    Text(
                                                      currentX.toStringAsFixed(
                                                        1,
                                                      ),
                                                      style:
                                                          GoogleFonts.jetBrainsMono(
                                                            fontSize: 22,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            color:
                                                                AppTheme.cyan,
                                                          ),
                                                    ),
                                                    const SizedBox(width: 4),
                                                    Text(
                                                      'm',
                                                      style:
                                                          GoogleFonts.jetBrainsMono(
                                                            fontSize: 11,
                                                            color: AppTheme
                                                                .textMid,
                                                          ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 6),
                                        Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  '${pct.toStringAsFixed(0)}% from roof',
                                                  style:
                                                      GoogleFonts.jetBrainsMono(
                                                        fontSize: 9,
                                                        color: AppTheme.cyan,
                                                      ),
                                                ),
                                                Text(
                                                  '↓ ${currentY.toStringAsFixed(1)}m from top',
                                                  style:
                                                      GoogleFonts.jetBrainsMono(
                                                        fontSize: 9,
                                                        color: AppTheme.textMid,
                                                      ),
                                                ),
                                              ],
                                            ),
                                            const SizedBox(width: 20),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  '${widthCoveredPct.toStringAsFixed(0)}% covered',
                                                  style:
                                                      GoogleFonts.jetBrainsMono(
                                                        fontSize: 9,
                                                        color: AppTheme.cyan,
                                                      ),
                                                ),
                                                Text(
                                                  '← ${widthRemaining.toStringAsFixed(1)}m left',
                                                  style:
                                                      GoogleFonts.jetBrainsMono(
                                                        fontSize: 9,
                                                        color: AppTheme.textMid,
                                                      ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 28,
                  margin: const EdgeInsets.only(left: 28),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    border: Border(top: BorderSide(color: AppTheme.borderDim)),
                  ),
                  child: Text(
                    'width: ${faceWidth.toStringAsFixed(1)}m',
                    style: GoogleFonts.jetBrainsMono(
                      fontSize: 11,
                      color: AppTheme.amber,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RobotPathPainter extends CustomPainter {
  final List<Offset> points;
  final double faceWidth;
  final double faceHeight;
  final int currentStrip;
  final int totalStrips;
  final double currentY;
  final double stripWidthPx;
  final Map<int, Map<String, int>> stripDirectionCounts;
  final int upCount;
  final int downCount;
  final ui.Image? botImage;

  _RobotPathPainter({
    required this.points,
    required this.faceWidth,
    required this.faceHeight,
    required this.currentStrip,
    required this.totalStrips,
    required this.currentY,
    required this.stripWidthPx,
    required this.stripDirectionCounts,
    required this.upCount,
    required this.downCount,
    required this.botImage,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final safeWidth = faceWidth > 0 ? faceWidth : 1.0;
    final safeHeight = faceHeight > 0 ? faceHeight : 1.0;

    // Scale X physical meters to pixel width of the canvas
    final scaleX = size.width / safeWidth;
    final scaleY = size.height / safeHeight;

    final glassRect = Rect.fromLTWH(0, 0, size.width, size.height);
    canvas.drawRect(
      glassRect,
      Paint()
        ..color = AppTheme.cyan.withOpacity(0.05)
        ..style = PaintingStyle.fill,
    );
    canvas.drawRect(
      glassRect,
      Paint()
        ..color = AppTheme.cyan.withOpacity(0.3)
        ..strokeWidth = 1.0
        ..style = PaintingStyle.stroke,
    );

    for (int i = 0; i < totalStrips; i++) {
      final stripLeft = i * stripWidthPx;
      if (i < currentStrip) {
        canvas.drawRect(
          Rect.fromLTWH(stripLeft, 0, stripWidthPx, size.height),
          Paint()
            ..color = AppTheme.cyan.withOpacity(0.35)
            ..style = PaintingStyle.fill,
        );
      } else if (i == currentStrip) {
        final cleanedFraction = currentY / safeHeight;
        final cleanedHeightPx = cleanedFraction * size.height;
        // Paint from TOP (0) to currentY
        canvas.drawRect(
          Rect.fromLTWH(stripLeft, 0, stripWidthPx, cleanedHeightPx),
          Paint()
            ..color = AppTheme.cyan.withOpacity(0.2)
            ..style = PaintingStyle.fill,
        );
        canvas.drawLine(
          Offset(stripLeft, cleanedHeightPx),
          Offset(stripLeft + stripWidthPx, cleanedHeightPx),
          Paint()
            ..color = AppTheme.cyan.withOpacity(0.9)
            ..strokeWidth = 2.0,
        );
      }
      canvas.drawLine(
        Offset(stripLeft, 0),
        Offset(stripLeft, size.height),
        Paint()
          ..color = AppTheme.cyan.withOpacity(0.15)
          ..strokeWidth = 0.5,
      );
    }

    for (int i = 0; i <= currentStrip; i++) {
      final double stripLeft = i * stripWidthPx;
      final double cx = stripLeft + stripWidthPx / 2;
      final up = i == currentStrip
          ? upCount
          : (stripDirectionCounts[i]?['up'] ?? 0);
      final down = i == currentStrip
          ? downCount
          : (stripDirectionCounts[i]?['down'] ?? 0);

      final double dynFont = (stripWidthPx * 0.3).clamp(9.0, 16.0);

      canvas.save();
      canvas.clipRect(Rect.fromLTWH(stripLeft, 0, stripWidthPx, size.height));

      final tp1 = TextPainter(
        text: TextSpan(
          text: '↑$up',
          style: TextStyle(
            color: const Color(0xFF1ABECC),
            fontSize: dynFont,
            fontWeight: FontWeight.bold,
          ),
        ),
        textDirection: TextDirection.ltr,
        textAlign: TextAlign.center,
      )..layout(maxWidth: stripWidthPx);
      tp1.paint(canvas, Offset(cx - tp1.width / 2, 4));

      final tp2 = TextPainter(
        text: TextSpan(
          text: '↓$down',
          style: TextStyle(
            color: const Color(0xFFD85A30),
            fontSize: dynFont,
            fontWeight: FontWeight.bold,
          ),
        ),
        textDirection: TextDirection.ltr,
        textAlign: TextAlign.center,
      )..layout(maxWidth: stripWidthPx);
      tp2.paint(
        canvas,
        Offset(cx - tp2.width / 2, size.height - tp2.height - 4),
      );

      canvas.restore();
    }

    if (points.isEmpty) return;

    final pathPaint = Paint()
      ..color = AppTheme.cyan
      ..strokeWidth = 2.0
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    final robotTrail = Path();
    robotTrail.moveTo(points.first.dx * scaleX, points.first.dy * scaleY);
    for (int i = 1; i < points.length; i++) {
      robotTrail.lineTo(points[i].dx * scaleX, points[i].dy * scaleY);
    }
    canvas.drawPath(robotTrail, pathPaint);

    final lastScaledX = points.last.dx * scaleX;
    final lastScaledY = points.last.dy * scaleY;
    canvas.drawCircle(
      Offset(lastScaledX, lastScaledY),
      20.0,
      Paint()..color = AppTheme.amber.withOpacity(0.2),
    );

    if (botImage != null) {
      final src = Rect.fromLTWH(
        0,
        0,
        botImage!.width.toDouble(),
        botImage!.height.toDouble(),
      );
      final double robotWidth = min(
        stripWidthPx * 0.75,
        size.width * 0.1,
      ).clamp(18.0, 38.0);
      final double robotHeight = robotWidth * 1.75;
      final dst = Rect.fromCenter(
        center: Offset(lastScaledX, lastScaledY),
        width: robotWidth,
        height: robotHeight,
      );
      canvas.drawImageRect(botImage!, src, dst, Paint());
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class _FaceInputButton extends StatefulWidget {
  final String faceName;
  final int currentFace;
  final int totalFaces;
  final double faceProgress;
  final double faceWidth;
  final double faceHeight;
  final Function(double, double) onDimensionsChanged;
  final VoidCallback onNextFace;
  final VoidCallback onPrevFace;

  const _FaceInputButton({
    required this.faceName,
    required this.currentFace,
    required this.totalFaces,
    required this.faceProgress,
    required this.faceWidth,
    required this.faceHeight,
    required this.onDimensionsChanged,
    required this.onNextFace,
    required this.onPrevFace,
  });

  @override
  State<_FaceInputButton> createState() => _FaceInputButtonState();
}

class _FaceInputButtonState extends State<_FaceInputButton> {
  bool _open = false;
  late TextEditingController _wCtrl;
  late TextEditingController _hCtrl;
  OverlayEntry? _overlay;
  final _layerLink = LayerLink();

  @override
  void initState() {
    super.initState();
    _wCtrl = TextEditingController(text: widget.faceWidth.toStringAsFixed(1));
    _hCtrl = TextEditingController(text: widget.faceHeight.toStringAsFixed(1));
  }

  void _toggleOverlay() {
    if (_open) {
      _overlay?.remove();
      _overlay = null;
      setState(() => _open = false);
    } else {
      _wCtrl.text = widget.faceWidth.toStringAsFixed(1);
      _hCtrl.text = widget.faceHeight.toStringAsFixed(1);

      _overlay = OverlayEntry(
        builder: (_) => CompositedTransformFollower(
          link: _layerLink,
          showWhenUnlinked: false,
          offset: const Offset(0, 34),
          child: Align(
            alignment: Alignment.topLeft,
            child: Material(
              color: Colors.transparent,
              child: Container(
                width: 260,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.bgCard,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppTheme.cyan.withOpacity(0.4)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'FACE DIMENSIONS',
                      style: GoogleFonts.jetBrainsMono(
                        fontSize: 9,
                        color: AppTheme.textMid,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.amber.withOpacity(0.2),
                              foregroundColor: AppTheme.amber,
                              side: BorderSide(color: AppTheme.amber),
                            ),
                            onPressed: () {
                              _overlay?.remove();
                              _overlay = null;
                              setState(() => _open = false);
                              widget.onPrevFace();
                            },
                            child: Text(
                              'PREV FACE',
                              style: GoogleFonts.jetBrainsMono(
                                fontWeight: FontWeight.bold,
                                fontSize: 11,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.cyan.withOpacity(0.2),
                              foregroundColor: AppTheme.cyan,
                              side: BorderSide(color: AppTheme.cyan),
                            ),
                            onPressed: () {
                              _overlay?.remove();
                              _overlay = null;
                              setState(() => _open = false);
                              widget.onNextFace();
                            },
                            child: Text(
                              'NEXT FACE',
                              style: GoogleFonts.jetBrainsMono(
                                fontWeight: FontWeight.bold,
                                fontSize: 11,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: _DimField(
                            label: 'WIDTH (m)',
                            controller: _wCtrl,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: _DimField(
                            label: 'HEIGHT (m)',
                            controller: _hCtrl,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.cyan.withOpacity(0.2),
                          foregroundColor: AppTheme.cyan,
                          side: BorderSide(color: AppTheme.cyan),
                          padding: const EdgeInsets.symmetric(vertical: 8),
                        ),
                        onPressed: () {
                          final w = double.tryParse(_wCtrl.text);
                          final h = double.tryParse(_hCtrl.text);
                          if (w != null && w > 0 && h != null && h > 0) {
                            widget.onDimensionsChanged(w, h);
                          }
                          _overlay?.remove();
                          _overlay = null;
                          setState(() => _open = false);
                        },
                        child: Text(
                          'APPLY DIMENSIONS',
                          style: GoogleFonts.jetBrainsMono(
                            fontWeight: FontWeight.bold,
                            fontSize: 11,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
      Overlay.of(context).insert(_overlay!);
      setState(() => _open = true);
    }
  }

  @override
  void dispose() {
    _overlay?.remove();
    _wCtrl.dispose();
    _hCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pct = widget.faceProgress.clamp(0.0, 100.0);

    return CompositedTransformTarget(
      link: _layerLink,
      child: GestureDetector(
        onTap: _toggleOverlay,
        child: Stack(
          children: [
            Positioned.fill(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: FractionallySizedBox(
                  alignment: Alignment.centerLeft,
                  widthFactor: pct / 100,
                  child: Container(color: AppTheme.cyan.withOpacity(0.18)),
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppTheme.cyan.withOpacity(_open ? 0.25 : 0.15),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: AppTheme.cyan),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    '${widget.faceName}  (${widget.currentFace}/${widget.totalFaces})',
                    style: GoogleFonts.jetBrainsMono(
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.cyan,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    '${pct.toStringAsFixed(0)}%',
                    style: GoogleFonts.jetBrainsMono(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.cyan.withOpacity(0.8),
                    ),
                  ),
                  const SizedBox(width: 4),
                  Icon(
                    _open ? Icons.expand_less : Icons.expand_more,
                    size: 14,
                    color: AppTheme.cyan,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DimField extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  const _DimField({required this.label, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.jetBrainsMono(
            fontSize: 8,
            color: AppTheme.textMid,
            letterSpacing: 0.8,
          ),
        ),
        const SizedBox(height: 4),
        TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          style: GoogleFonts.jetBrainsMono(
            fontSize: 13,
            color: AppTheme.textHi,
          ),
          decoration: InputDecoration(
            isDense: true,
            hintText: '0.0',
            hintStyle: GoogleFonts.jetBrainsMono(
              fontSize: 13,
              color: AppTheme.textLo,
            ),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 8,
              vertical: 6,
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(4),
              borderSide: BorderSide(color: AppTheme.borderDim),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(4),
              borderSide: BorderSide(color: AppTheme.cyan),
            ),
            filled: true,
            fillColor: AppTheme.bg,
          ),
        ),
      ],
    );
  }
}

class _ConfigTab extends StatelessWidget {
  final Task task;
  final VoidCallback onTaskUpdated;

  const _ConfigTab({required this.task, required this.onTaskUpdated});

  Future<void> _editCameraLink(
    BuildContext context,
    String cameraName,
    String currentLink,
    Function(String) onSave,
  ) async {
    final ctrl = TextEditingController(text: currentLink);
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.bgPanel,
        title: Text(
          'Edit $cameraName Link',
          style: GoogleFonts.barlowCondensed(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: AppTheme.textHi,
          ),
        ),
        content: GcsTextField(
          controller: ctrl,
          label: 'RTSP URL',
          hint: 'rtsp://...',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(
              'CANCEL',
              style: GoogleFonts.jetBrainsMono(
                fontSize: 11,
                color: AppTheme.textMid,
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              onSave(ctrl.text.trim());
              Navigator.pop(ctx);
            },
            child: Text(
              'SAVE',
              style: GoogleFonts.jetBrainsMono(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: AppTheme.cyan,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pad = AppTheme.screenPad(context);
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: pad, vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GcsSectionLabel('Task Details'),
          const SizedBox(height: 12),
          GcsCard(
            child: Column(
              children: [
                _CfgRow('Building', task.buildingName ?? ''),
                Divider(color: AppTheme.borderDim, height: 20),
                _CfgRow('Height', '${task.buildingHeight} m'),
                Divider(color: AppTheme.borderDim, height: 20),
                _CfgRow('Approx. Surface area', '${task.surfaceArea} m²'),
                Divider(color: AppTheme.borderDim, height: 20),
                _CfgRow('Device ID', task.deviceId ?? ''),
              ],
            ),
          ),
          const SizedBox(height: 20),
          GcsSectionLabel('Data & Hardware Connections'),
          const SizedBox(height: 12),
          GcsCard(
            child: Column(
              children: [
                _CfgRow(
                  'Camera A Link',
                  (task.cameraALink?.isEmpty ?? true)
                      ? 'Not Set'
                      : task.cameraALink!,
                  isEditable: true,
                  onEdit: () => _editCameraLink(
                    context,
                    'Camera A',
                    task.cameraALink ?? '',
                    (newVal) async {
                      task.cameraALink = newVal;
                      await IsarService.updateTask(task);
                      onTaskUpdated();
                    },
                  ),
                ),
                Divider(color: AppTheme.borderDim, height: 20),
                _CfgRow(
                  'Camera B Link',
                  (task.cameraBLink?.isEmpty ?? true)
                      ? 'Not Set'
                      : task.cameraBLink!,
                  isEditable: true,
                  onEdit: () => _editCameraLink(
                    context,
                    'Camera B',
                    task.cameraBLink ?? '',
                    (newVal) async {
                      task.cameraBLink = newVal;
                      await IsarService.updateTask(task);
                      onTaskUpdated();
                    },
                  ),
                ),
                Divider(color: AppTheme.borderDim, height: 20),
                const _CfgRow('Telemetry', 'MANUAL SELECTION'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CfgRow extends StatelessWidget {
  final String label, value;
  final bool isEditable;
  final VoidCallback? onEdit;

  const _CfgRow(this.label, this.value, {this.isEditable = false, this.onEdit});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: GoogleFonts.jetBrainsMono(
            fontSize: 11,
            color: AppTheme.textMid,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: GestureDetector(
            onTap: isEditable ? onEdit : null,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Flexible(
                  child: Text(
                    value,
                    textAlign: TextAlign.right,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.barlowCondensed(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: isEditable ? AppTheme.cyan : AppTheme.textHi,
                    ),
                  ),
                ),
                if (isEditable) ...[
                  const SizedBox(width: 8),
                  Icon(Icons.edit_rounded, size: 14, color: AppTheme.cyan),
                ],
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _SnapsTab extends StatefulWidget {
  final Task task;
  const _SnapsTab({required this.task});

  @override
  State<_SnapsTab> createState() => _SnapsTabState();
}

class _SnapsTabState extends State<_SnapsTab> {
  Future<void> _deleteSnapshot(TaskSnapshot snap) async {
    if (snap.filePath != null) {
      try {
        final file = File(snap.filePath!);
        if (file.existsSync()) {
          await file.delete();
        }
      } catch (e) {
        debugPrint('Failed to delete snapshot file: $e');
      }
    }

    final updatedSnapshots = List<TaskSnapshot>.from(widget.task.snapshots);
    updatedSnapshots.remove(snap);
    widget.task.snapshots = updatedSnapshots;
    widget.task.isSynced = false;
    await IsarService.updateTask(widget.task);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (widget.task.snapshots.isEmpty) {
      return const Center(child: Text("No snapshots yet."));
    }

    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
      ),
      itemCount: widget.task.snapshots.length,
      itemBuilder: (context, index) {
        final snap = widget.task.snapshots[index];
        return Stack(
          fit: StackFit.expand,
          children: [
            GestureDetector(
              onTap: () {
                showGeneralDialog(
                  context: context,
                  barrierColor: Colors.black.withOpacity(0.95),
                  barrierDismissible: true,
                  barrierLabel: 'SnapViewer',
                  pageBuilder: (ctx, _, __) => _SnapshotViewer(
                    snap: snap,
                    task: widget.task,
                    onUpdate: () => setState(() {}),
                  ),
                );
              },
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.file(File(snap.filePath!), fit: BoxFit.cover),
              ),
            ),
            Positioned(
              top: 8,
              right: 8,
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: IconButton(
                  icon: const Icon(Icons.delete_outline, size: 18, color: Colors.white),
                  padding: const EdgeInsets.all(6),
                  constraints: const BoxConstraints(),
                  tooltip: 'Delete snapshot',
                  onPressed: () async {
                    final confirmed = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        backgroundColor: AppTheme.bgPanel,
                        title: Text('Delete Snapshot', style: TextStyle(color: AppTheme.textHi)),
                        content: const Text('Delete this snapshot permanently?'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(ctx, false),
                            child: const Text('CANCEL'),
                          ),
                          TextButton(
                            onPressed: () => Navigator.pop(ctx, true),
                            child: Text('DELETE', style: TextStyle(color: AppTheme.red)),
                          ),
                        ],
                      ),
                    );
                    if (confirmed == true) {
                      await _deleteSnapshot(snap);
                    }
                  },
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                color: Colors.black54,
                padding: const EdgeInsets.all(4),
                child: Text(
                  '${snap.cameraName}',
                  style: const TextStyle(color: Colors.white, fontSize: 9),
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _SnapshotViewer extends StatefulWidget {
  final TaskSnapshot snap;
  final Task task;
  final VoidCallback onUpdate;

  const _SnapshotViewer({
    required this.snap,
    required this.task,
    required this.onUpdate,
  });

  @override
  State<_SnapshotViewer> createState() => _SnapshotViewerState();
}

class _SnapshotViewerState extends State<_SnapshotViewer> {
  bool _showInfo = false;

  void _editName() {
    final ctrl = TextEditingController(text: widget.snap.cameraName);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.bgPanel,
        title: Text('Edit Name', style: TextStyle(color: AppTheme.textHi)),
        content: TextField(
          controller: ctrl,
          style: TextStyle(color: AppTheme.textHi),
          decoration: const InputDecoration(hintText: "Enter new name"),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('CANCEL'),
          ),
          TextButton(
            onPressed: () async {
              setState(() {
                widget.snap.cameraName = ctrl.text.trim();
                widget.task.isSynced = false;
              });
              await IsarService.updateTask(widget.task);
              widget.onUpdate();
              Navigator.pop(ctx);
            },
            child: Text('SAVE', style: TextStyle(color: AppTheme.cyan)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    File imgFile = File(widget.snap.filePath!);
    String fileName = imgFile.path.split('/').last;

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Stack(
          children: [
            Center(
              child: InteractiveViewer(
                minScale: 0.5,
                maxScale: 4.0,
                child: Image.file(imgFile),
              ),
            ),
            Positioned(
              top: 16,
              right: 16,
              child: IconButton(
                icon: const Icon(
                  Icons.close_rounded,
                  color: Colors.white,
                  size: 32,
                ),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            if (_showInfo)
              Positioned(
                bottom: 90,
                left: 20,
                right: 20,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.65),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.white24),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'FILE INFO',
                        style: GoogleFonts.jetBrainsMono(
                          color: AppTheme.cyan,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Name:     $fileName',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                        ),
                      ),
                      Text(
                        'Created:  ${widget.snap.timestamp.toString().split('.')[0]}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                        ),
                      ),
                      const Text(
                        'Location: No Info',
                        style: TextStyle(color: Colors.white, fontSize: 11),
                      ),
                    ],
                  ),
                ),
              ),
            Positioned(
              bottom: 20,
              left: 0,
              right: 0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _actionBtn(
                    Icons.info_outline,
                    "Info",
                    () => setState(() => _showInfo = !_showInfo),
                  ),
                  const SizedBox(width: 20),
                  _actionBtn(Icons.edit_rounded, "Edit", _editName),
                  const SizedBox(width: 20),
                  _actionBtn(Icons.delete_outline, "Delete", _confirmDelete),
                  const SizedBox(width: 20),
                  _actionBtn(Icons.share_rounded, "Share", () {
                    Share.shareXFiles([
                      XFile(imgFile.path),
                    ], text: 'Wiperque Snapshot: ${widget.snap.cameraName}');
                  }),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmDelete() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.bgPanel,
        title: Text('Delete Snapshot', style: TextStyle(color: AppTheme.textHi)),
        content: const Text('Delete this snapshot permanently?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('CANCEL'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text('DELETE', style: TextStyle(color: AppTheme.red)),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await _deleteSnapshot();
    }
  }

  Future<void> _deleteSnapshot() async {
    if (widget.snap.filePath != null) {
      try {
        final file = File(widget.snap.filePath!);
        if (file.existsSync()) {
          await file.delete();
        }
      } catch (e) {
        debugPrint('Failed to delete snapshot file: $e');
      }
    }

    final updatedSnapshots = List<TaskSnapshot>.from(widget.task.snapshots);
    updatedSnapshots.remove(widget.snap);
    widget.task.snapshots = updatedSnapshots;
    widget.task.isSynced = false;
    await IsarService.updateTask(widget.task);
    widget.onUpdate();
    if (mounted) Navigator.pop(context);
  }

  Widget _actionBtn(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(
              color: Colors.black54,
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: Colors.white, size: 24),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(color: Colors.white, fontSize: 10),
          ),
        ],
      ),
    );
  }
}

class _VideosTab extends StatefulWidget {
  final Task task;
  const _VideosTab({required this.task});

  @override
  State<_VideosTab> createState() => _VideosTabState();
}

class _VideosTabState extends State<_VideosTab> {
  Future<void> _deleteVideo(TaskVideo video) async {
    if (video.filePath != null) {
      try {
        final file = File(video.filePath!);
        if (file.existsSync()) {
          await file.delete();
        }
      } catch (e) {
        debugPrint('Failed to delete video file: $e');
      }
    }

    final updatedVideos = List<TaskVideo>.from(widget.task.videos);
    updatedVideos.remove(video);
    widget.task.videos = updatedVideos;
    widget.task.isSynced = false;
    await IsarService.updateTask(widget.task);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (widget.task.videos.isEmpty) {
      return const Center(child: Text("No recorded videos."));
    }

    final validVideos = widget.task.videos
        .where(
          (v) =>
              v.filePath != null &&
              File(v.filePath!).existsSync() &&
              File(v.filePath!).lengthSync() > 0,
        )
        .toList();

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: widget.task.videos.length,
      itemBuilder: (ctx, i) {
        final video = widget.task.videos[i];
        final fileName = video.filePath?.split('/').last ?? 'Unknown';
        final bool isValidFile = validVideos.contains(video);

        return Card(
          color: AppTheme.bgCard,
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 8,
            ),
            leading: SizedBox(
              width: 60,
              height: 60,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: isValidFile
                    ? _VideoThumbnail(videoPath: video.filePath!)
                    : Container(
                        color: AppTheme.bgPanel,
                        child: Icon(
                          Icons.broken_image_rounded,
                          color: AppTheme.textLo,
                          size: 24,
                        ),
                      ),
              ),
            ),
            title: Text(
              video.cameraName ?? 'Video Record',
              style: TextStyle(
                color: isValidFile ? AppTheme.textHi : AppTheme.textLo,
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text(
              '${video.timestamp.toString().split('.')[0]}\n$fileName',
              style: TextStyle(color: AppTheme.textLo, fontSize: 11),
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(
                    Icons.share_rounded,
                    color: isValidFile ? AppTheme.cyan : AppTheme.borderDim,
                  ),
                  onPressed: () async {
                    if (isValidFile) {
                      await Share.shareXFiles([
                        XFile(video.filePath!),
                      ], text: 'Recorded Stream');
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('File corrupted or missing.')),
                      );
                    }
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.delete_outline, color: Colors.white),
                  tooltip: 'Delete video',
                  onPressed: () async {
                    final confirmed = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        backgroundColor: AppTheme.bgPanel,
                        title: Text('Delete Video', style: TextStyle(color: AppTheme.textHi)),
                        content: const Text('Delete this video permanently?'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(ctx, false),
                            child: const Text('CANCEL'),
                          ),
                          TextButton(
                            onPressed: () => Navigator.pop(ctx, true),
                            child: Text('DELETE', style: TextStyle(color: AppTheme.red)),
                          ),
                        ],
                      ),
                    );
                    if (confirmed == true) {
                      await _deleteVideo(video);
                    }
                  },
                ),
              ],
            ),
            onTap: () {
              if (isValidFile) {
                final initialIndex = validVideos.indexOf(video);
                showGeneralDialog(
                  context: context,
                  barrierColor: Colors.black.withOpacity(0.95),
                  barrierDismissible: true,
                  barrierLabel: 'VideoViewer',
                  pageBuilder: (ctx, _, __) => _VideoViewer(
                    videos: validVideos,
                    initialIndex: initialIndex,
                  ),
                );
              }
            },
          ),
        );
      },
    );
  }
}

class _VideoThumbnail extends StatefulWidget {
  final String videoPath;
  const _VideoThumbnail({required this.videoPath});
  @override
  State<_VideoThumbnail> createState() => _VideoThumbnailState();
}

class _VideoThumbnailState extends State<_VideoThumbnail> {
  Uint8List? _thumbData;
  @override
  void initState() {
    super.initState();
    _generateThumbnail();
  }

  Future<void> _generateThumbnail() async {
    try {
      final uint8list = await VideoThumbnail.thumbnailData(
        video: widget.videoPath,
        imageFormat: ImageFormat.JPEG,
        maxWidth: 150,
        quality: 50,
      );
      if (mounted) setState(() => _thumbData = uint8list);
    } catch (e) {
      debugPrint("Thumbnail error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_thumbData == null) {
      return Container(
        color: Colors.black45,
        child: const Center(child: CircularProgressIndicator(strokeWidth: 2)),
      );
    }
    return Stack(
      fit: StackFit.expand,
      children: [
        Image.memory(_thumbData!, fit: BoxFit.cover),
        Container(color: Colors.black26),
        const Center(
          child: Icon(
            Icons.play_circle_fill_rounded,
            color: Colors.white,
            size: 24,
          ),
        ),
      ],
    );
  }
}

class _VideoViewer extends StatefulWidget {
  final List<TaskVideo> videos;
  final int initialIndex;

  const _VideoViewer({required this.videos, required this.initialIndex});

  @override
  State<_VideoViewer> createState() => _VideoViewerState();
}

class _VideoViewerState extends State<_VideoViewer> {
  late final Player player;
  late final VideoController controller;
  late int currentIndex;

  bool _showControls = true;
  bool _isPlaying = true;
  Timer? _hideControlsTimer;

  BoxFit _currentFit = BoxFit.contain;
  final TransformationController _zoomCtrl = TransformationController();

  final List<double> _speeds = [1.0, 2.0, 4.0, 6.0, 8.0, 10.0];
  int _speedIndex = 0;

  int _seekAccumulator = 0;
  Timer? _seekOverlayTimer;

  @override
  void initState() {
    super.initState();
    currentIndex = widget.initialIndex;
    player = Player();
    controller = VideoController(player);
    _loadVideo(currentIndex);
    _startControlsTimer();

    player.stream.playing.listen((playing) {
      if (mounted) setState(() => _isPlaying = playing);
    });
  }

  void _loadVideo(int index) {
    final path = widget.videos[index].filePath;
    if (path != null) {
      player.open(Media(path), play: true);
      setState(() {
        _speedIndex = 0;
        player.setRate(1.0);
      });
    }
  }

  void _nextVideo() {
    if (currentIndex < widget.videos.length - 1) {
      setState(() => currentIndex++);
      _loadVideo(currentIndex);
    }
  }

  void _prevVideo() {
    if (currentIndex > 0) {
      setState(() => currentIndex--);
      _loadVideo(currentIndex);
    }
  }

  void _cycleSpeed() {
    setState(() {
      _speedIndex = (_speedIndex + 1) % _speeds.length;
      player.setRate(_speeds[_speedIndex]);
    });
  }

  void _togglePlay() {
    _isPlaying ? player.pause() : player.play();
    _resetControlsTimer();
  }

  void _toggleControls() {
    setState(() => _showControls = !_showControls);
    if (_showControls) _startControlsTimer();
  }

  void _startControlsTimer() {
    _hideControlsTimer?.cancel();
    _hideControlsTimer = Timer(const Duration(seconds: 4), () {
      if (mounted && _isPlaying) setState(() => _showControls = false);
    });
  }

  void _resetControlsTimer() {
    if (_showControls) _startControlsTimer();
  }

  void _handleDoubleTapSeek(bool isForward) {
    final step = const Duration(seconds: 10);
    setState(() {
      _seekAccumulator += isForward ? 10 : -10;
    });

    final currentPos = player.state.position;
    player.seek(currentPos + (isForward ? step : -step));

    _seekOverlayTimer?.cancel();
    _seekOverlayTimer = Timer(const Duration(milliseconds: 1000), () {
      if (mounted) setState(() => _seekAccumulator = 0);
    });
  }

  @override
  void dispose() {
    _hideControlsTimer?.cancel();
    _seekOverlayTimer?.cancel();
    _zoomCtrl.dispose();
    player.dispose();
    super.dispose();
  }

  String _formatDuration(Duration d) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final m = twoDigits(d.inMinutes.remainder(60));
    final s = twoDigits(d.inSeconds.remainder(60));
    if (d.inHours > 0) return '${d.inHours}:$m:$s';
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final fileName =
        widget.videos[currentIndex].filePath?.split('/').last ?? '';

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Stack(
          fit: StackFit.expand,
          children: [
            Center(
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: InteractiveViewer(
                  transformationController: _zoomCtrl,
                  minScale: 1.0,
                  maxScale: 20.0,
                  child: Video(
                    controller: controller,
                    fit: _currentFit,
                    controls: NoVideoControls,
                  ),
                ),
              ),
            ),

            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: _toggleControls,
                    onDoubleTap: () => _handleDoubleTapSeek(false),
                    behavior: HitTestBehavior.translucent,
                  ),
                ),
                Expanded(
                  child: GestureDetector(
                    onTap: _toggleControls,
                    behavior: HitTestBehavior.translucent,
                  ),
                ),
                Expanded(
                  child: GestureDetector(
                    onTap: _toggleControls,
                    onDoubleTap: () => _handleDoubleTapSeek(true),
                    behavior: HitTestBehavior.translucent,
                  ),
                ),
              ],
            ),

            if (_seekAccumulator != 0)
              Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 12,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.black54,
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Text(
                    '${_seekAccumulator > 0 ? "+" : ""}${_seekAccumulator}s',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),

            if (_showControls)
              Container(
                color: Colors.black45,
                child: Stack(
                  children: [
                    Positioned(
                      top: 16,
                      left: 24,
                      right: 16,
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              fileName,
                              style: GoogleFonts.jetBrainsMono(
                                color: AppTheme.cyan,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          TextButton(
                            onPressed: () {
                              _cycleSpeed();
                              _resetControlsTimer();
                            },
                            child: Text(
                              '${_speeds[_speedIndex].toInt()}x',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          PopupMenuButton<String>(
                            icon: const Icon(
                              Icons.more_vert_rounded,
                              color: Colors.white,
                            ),
                            color: AppTheme.bgPanel,
                            onSelected: (val) {
                              _resetControlsTimer();
                              if (val == 'fit')
                                setState(() => _currentFit = BoxFit.contain);
                              if (val == 'fill')
                                setState(() => _currentFit = BoxFit.cover);
                              if (val == 'stretch')
                                setState(() => _currentFit = BoxFit.fill);
                              if (val == 'reset_zoom')
                                _zoomCtrl.value = Matrix4.identity();
                            },
                            itemBuilder: (ctx) => [
                              const PopupMenuItem(
                                value: 'fit',
                                child: Text(
                                  'Aspect: Fit',
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                              const PopupMenuItem(
                                value: 'fill',
                                child: Text(
                                  'Aspect: Crop/Fill',
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                              const PopupMenuItem(
                                value: 'stretch',
                                child: Text(
                                  'Aspect: Stretch',
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                              const PopupMenuDivider(),
                              PopupMenuItem(
                                value: 'reset_zoom',
                                child: Text(
                                  'Reset Zoom',
                                  style: TextStyle(color: AppTheme.cyan),
                                ),
                              ),
                            ],
                          ),
                          IconButton(
                            icon: const Icon(
                              Icons.close_rounded,
                              color: Colors.white,
                              size: 32,
                            ),
                            onPressed: () => Navigator.pop(context),
                          ),
                        ],
                      ),
                    ),

                    Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          IconButton(
                            iconSize: 42,
                            color: currentIndex > 0
                                ? Colors.white
                                : Colors.white30,
                            icon: const Icon(Icons.skip_previous_rounded),
                            onPressed: currentIndex > 0
                                ? () {
                                    _prevVideo();
                                    _resetControlsTimer();
                                  }
                                : null,
                          ),
                          const SizedBox(width: 30),
                          IconButton(
                            iconSize: 42,
                            color: Colors.white,
                            icon: const Icon(Icons.replay_10_rounded),
                            onPressed: () {
                              _handleDoubleTapSeek(false);
                              _resetControlsTimer();
                            },
                          ),
                          const SizedBox(width: 30),
                          GestureDetector(
                            onTap: _togglePlay,
                            child: Icon(
                              _isPlaying
                                  ? Icons.pause_circle_outline_rounded
                                  : Icons.play_circle_outline_rounded,
                              color: Colors.white,
                              size: 80,
                            ),
                          ),
                          const SizedBox(width: 30),
                          IconButton(
                            iconSize: 42,
                            color: Colors.white,
                            icon: const Icon(Icons.forward_10_rounded),
                            onPressed: () {
                              _handleDoubleTapSeek(true);
                              _resetControlsTimer();
                            },
                          ),
                          const SizedBox(width: 30),
                          IconButton(
                            iconSize: 42,
                            color: currentIndex < widget.videos.length - 1
                                ? Colors.white
                                : Colors.white30,
                            icon: const Icon(Icons.skip_next_rounded),
                            onPressed: currentIndex < widget.videos.length - 1
                                ? () {
                                    _nextVideo();
                                    _resetControlsTimer();
                                  }
                                : null,
                          ),
                        ],
                      ),
                    ),

                    Positioned(
                      bottom: 24,
                      left: 24,
                      right: 24,
                      child: StreamBuilder<Duration>(
                        stream: player.stream.position,
                        builder: (context, snapshot) {
                          final position = snapshot.data ?? Duration.zero;
                          final duration = player.state.duration;
                          return Row(
                            children: [
                              Text(
                                _formatDuration(position),
                                style: const TextStyle(color: Colors.white),
                              ),
                              Expanded(
                                child: SliderTheme(
                                  data: SliderTheme.of(context).copyWith(
                                    thumbColor: AppTheme.cyan,
                                    activeTrackColor: AppTheme.cyan,
                                    inactiveTrackColor: Colors.white30,
                                  ),
                                  child: Slider(
                                    value: position.inMilliseconds
                                        .toDouble()
                                        .clamp(
                                          0,
                                          duration.inMilliseconds.toDouble(),
                                        ),
                                    max: duration.inMilliseconds > 0
                                        ? duration.inMilliseconds.toDouble()
                                        : 1.0,
                                    onChanged: (val) {
                                      player.seek(
                                        Duration(milliseconds: val.toInt()),
                                      );
                                      _resetControlsTimer();
                                    },
                                  ),
                                ),
                              ),
                              Text(
                                _formatDuration(duration),
                                style: const TextStyle(color: Colors.white),
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _AlertsTab extends StatelessWidget {
  final Task task;
  const _AlertsTab({required this.task});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: task.alerts.length,
      itemBuilder: (ctx, i) {
        final alert = task.alerts[i];
        final isCritical = alert.type == 'CRITICAL';
        return Card(
          color: AppTheme.bgCard,
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: Icon(
              isCritical ? Icons.warning_rounded : Icons.info_outline,
              color: isCritical ? AppTheme.red : AppTheme.amber,
            ),
            title: Text(
              alert.message ?? 'Unknown Alert',
              style: TextStyle(
                color: AppTheme.textHi,
                fontSize: 13,
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text(
              alert.timestamp.toString().split('.')[0],
              style: TextStyle(color: AppTheme.textLo, fontSize: 11),
            ),
          ),
        );
      },
    );
  }
}





// airunit:

// import 'dart:async';
// import 'dart:convert';
// import 'dart:io';
// import 'dart:math';
// import 'dart:typed_data';
// import 'dart:ui' as ui;

// import 'package:fl_chart/fl_chart.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_tts/flutter_tts.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:media_kit/media_kit.dart';
// import 'package:media_kit_video/media_kit_video.dart';
// import 'package:share_plus/share_plus.dart';
// import 'package:video_thumbnail/video_thumbnail.dart';
// import 'package:vivid_mapping_sandbox/core/db/isar_service.dart';
// import 'package:vivid_mapping_sandbox/core/models/task.dart';
// import 'package:vivid_mapping_sandbox/modules/wiper-gcs/sections/telemetry.dart';
// import 'package:vivid_mapping_sandbox/modules/wiper-gcs/widgets/camera_view.dart';
// import 'package:vivid_mapping_sandbox/ui/app_theme.dart';
// import 'package:vivid_mapping_sandbox/ui/gcs_sidebar.dart';
// import 'package:vivid_mapping_sandbox/ui/gcs_widgets.dart';
// import 'package:flutter/foundation.dart';

// class WiperMainScreen extends StatefulWidget {
//   final Task task;
//   final bool isActive;

//   const WiperMainScreen({
//     super.key,
//     required this.task,
//     required this.isActive,
//   });

//   @override
//   State<WiperMainScreen> createState() => _WiperMainScreenState();
// }

// class _WiperMainScreenState extends State<WiperMainScreen>
//     with TickerProviderStateMixin {
//   late TabController _tabCtrl;
//   late final WiperTelemetry _telemetry;
//   int _tab = 0;

//   int _currentStrip = 0;
//   int get _totalStrips => (_faceWidth / _robotCleaningWidth).floor();

//   int _currentFace = 1;
//   double _faceStartY = 0.0;

//   double _faceWidth = 0.0;
//   double _faceHeight = 0.0;

//   int _upCount = 0;
//   int _downCount = 0;

//   // Track if bot has touched the top/bottom boundary to prevent multiple counts
//   bool _isAtTop = false;
//   bool _isAtBottom = true;

//   Map<int, Map<int, Map<String, int>>> _faceStripCounts = {};
//   Map<int, Map<String, double>> _faceSnapshot = {};

//   Map<int, Map<String, double>> _faceDimensions = {};

//   late final FlutterTts _tts;
//   bool _waterWarningPlayed = false;
//   bool _batteryWarningPlayed = false;

//   Timer? _autoSaveTimer;
//   double _lastSavedWater = 0;
//   double _lastSavedEnergy = 0;

//   ui.Image? _botImage;
//   List<Offset> _robotPath = [];
//   double _currentX = 0.0;
//   double _currentY = 0.0;
//   final double _robotCleaningWidth = 0.9;

//   // @override
//   // void initState() {
//   //   super.initState();
//   //   _currentStrip = widget.task.currentStrip;
//   //   _currentFace = widget.task.currentFace;

//   //   _faceHeight = widget.task.buildingHeight > 0
//   //       ? widget.task.buildingHeight
//   //       : 50.0;
//   //   int facesCount =
//   //       widget.task.numberOfFaces != null && widget.task.numberOfFaces! > 0
//   //       ? widget.task.numberOfFaces!
//   //       : 1;
//   //   _faceWidth = (widget.task.surfaceArea / (_faceHeight * facesCount)).clamp(
//   //     1.0,
//   //     double.infinity,
//   //   );

//   //   // DECODE PERSISTENT HISTORY FROM ISAR
//   //   if (widget.task.mappingState.isNotEmpty &&
//   //       widget.task.mappingState != "{}") {
//   //     try {
//   //       final Map<String, dynamic> state = jsonDecode(widget.task.mappingState);
//   //       _upCount = state['upCount'] ?? 0;
//   //       _downCount = state['downCount'] ?? 0;
//   //       _currentX = state['currentX'] ?? 0.0;

//   //       // changed on 14-08-2026
//   //       // _currentY = state['currentY'] ?? _faceHeight;
//   //       _currentY = state['currentY'] ?? 50.0; // fallback

//   //       if (state['faceStripCounts'] != null) {
//   //         final decodedFSC = Map<String, dynamic>.from(
//   //           state['faceStripCounts'],
//   //         );
//   //         decodedFSC.forEach((faceStr, stripMap) {
//   //           int faceId = int.parse(faceStr);
//   //           _faceStripCounts[faceId] = {};
//   //           Map<String, dynamic>.from(stripMap).forEach((stripStr, countMap) {
//   //             _faceStripCounts[faceId]![int.parse(stripStr)] =
//   //                 Map<String, int>.from(countMap);
//   //           });
//   //         });
//   //       }

//   //       // added on 14-08-2026 for Mapping Tab static width

//   //       if (state['faceDimensions'] != null) {
//   //         final decodedDims = Map<String, dynamic>.from(state['faceDimensions']);
//   //         decodedDims.forEach((faceStr, dimMap) {
//   //           _faceDimensions[int.parse(faceStr)] = Map<String, double>.from(
//   //               dimMap.map((k, v) => MapEntry(k, (v as num).toDouble()))
//   //           );
//   //         });
//   //       }


//   //     } catch (e) {
//   //       debugPrint("Error decoding mapping state: $e");
//   //       _resetToBottom();
//   //     }
//   //   } 
    
//   //   // 👉 Replacing THE OLD MATH WITH THE HELPER
//   //   _loadDimensionsForFace(_currentFace);
    
//   //   else {
//   //     _resetToBottom();
//   //   }

//   //   _initTabController();

//   //   _telemetry = WiperTelemetry();
//   //   _telemetry.addListener(_processOdometry);

//   //   _tts = FlutterTts();
//   //   _tts.setLanguage("en-US");
//   //   _tts.setSpeechRate(0.5);

//   //   if (widget.isActive) {
//   //     _telemetry.initConnection();
//   //     _autoSaveTimer = Timer.periodic(
//   //       const Duration(seconds: 5),
//   //       (_) => _saveTelemetryToTask(),
//   //     );
//   //   }

//   //   const AssetImage('assets/bot_image.png')
//   //       .resolve(const ImageConfiguration())
//   //       .addListener(
//   //         ImageStreamListener((ImageInfo info, bool _) {
//   //           if (mounted) setState(() => _botImage = info.image);
//   //         }),
//   //       );
//   // }

//   // did this change on 14-08-2026 due to resolving of Static Mapping placement history

//   @override
//   void initState() {
//     super.initState();
//     _currentStrip = widget.task.currentStrip;
//     _currentFace = widget.task.currentFace;

//     bool loadedFromState = false;

//     // DECODE PERSISTENT HISTORY FROM ISAR
//     if (widget.task.mappingState.isNotEmpty && widget.task.mappingState != "{}") {
//       try {
//         final Map<String, dynamic> state = jsonDecode(widget.task.mappingState);
//         _upCount = state['upCount'] ?? 0;
//         _downCount = state['downCount'] ?? 0;
//         _currentX = state['currentX'] ?? 0.0;
//         _currentY = state['currentY'] ?? 50.0; // fallback

//         if (state['faceStripCounts'] != null) {
//           final decodedFSC = Map<String, dynamic>.from(state['faceStripCounts']);
//           decodedFSC.forEach((faceStr, stripMap) {
//             int faceId = int.parse(faceStr);
//             _faceStripCounts[faceId] = {};
//             Map<String, dynamic>.from(stripMap).forEach((stripStr, countMap) {
//               _faceStripCounts[faceId]![int.parse(stripStr)] =
//                   Map<String, int>.from(countMap);
//             });
//           });
//         }

//         // 👉 ADDED: MISSING SNAPSHOT DECODER
//         if (state['faceSnapshot'] != null) {
//           final snapMap = Map<String, dynamic>.from(state['faceSnapshot']);
//           snapMap.forEach((k, v) {
//             final vMap = v as Map;
//             _faceSnapshot[int.parse(k)] = {
//               'strip': (vMap['strip'] as num).toDouble(),
//               'y': (vMap['y'] as num).toDouble(),
//             };
//           });
//         }

//         // 👉 FIXED: TYPE-SAFE DIMENSIONS DECODER
//         if (state['faceDimensions'] != null) {
//           final decodedDims = Map<String, dynamic>.from(state['faceDimensions']);
//           decodedDims.forEach((faceStr, dimMap) {
//             final dMap = dimMap as Map; // Safe casting prevents crashes
//             _faceDimensions[int.parse(faceStr)] = {
//               'w': (dMap['w'] as num).toDouble(),
//               'h': (dMap['h'] as num).toDouble(),
//             };
//           });
//         }

//         loadedFromState = true;
//       } catch (e) {
//         debugPrint("Error decoding mapping state: $e");
//       }
//     } 

//     // 👉 ALWAYS APPLY DIMENSIONS (From decoded JSON or Fallback Math)
//     _loadDimensionsForFace(_currentFace);

//     // 👉 CRITICAL: SET INITIAL ROBOT PATH SO TRAIL DOESN'T DISAPPEAR
//     if (loadedFromState) {
//       _robotPath = [Offset(_currentX, _currentY)];
//       _faceStartY = _currentY;
//     } else {
//       _resetToBottom();
//     }

//     _initTabController();

//     _telemetry = WiperTelemetry();
//     _telemetry.addListener(_processOdometry);
// // // air unit linked notification
// //     _telemetry.onAirUnitLinked = () {

// //       if (mounted) {
// //         ScaffoldMessenger.of(context).showSnackBar(
// //         const SnackBar(content: Text('Air Unit Linked')),
// //       );
// //     }
// // };

//     _tts = FlutterTts();
//     _tts.setLanguage("en-US");
//     _tts.setSpeechRate(0.5);

//     if (widget.isActive) {
//       _telemetry.initConnection();
//       _autoSaveTimer = Timer.periodic(
//         const Duration(seconds: 5),
//         (_) => _saveTelemetryToTask(),
//       );
//     }

//     const AssetImage('assets/bot_image.png')
//         .resolve(const ImageConfiguration())
//         .addListener(
//           ImageStreamListener((ImageInfo info, bool _) {
//             if (mounted) setState(() => _botImage = info.image);
//           }),
//         );
//   }

//   // did the above functional change on 14-08-2026 regarding Mapping glitch

//   void _resetToBottom() {
//     // 1. Calculate strips
//     final int totalS = (_faceWidth / _robotCleaningWidth).floor();
//     final double stripWidth = totalS > 0 ? _faceWidth / totalS : _faceWidth;

//     // 2. Put the bot exactly in the horizontal center of the face
//     _currentX = (_currentStrip * stripWidth) + (stripWidth / 2);

//     // 3. Put the bot at the exact bottom of the face (ground level)
//     _currentY = _faceHeight; // Bot defaults to bottom center
//     _faceStartY = _currentY;

//     // 4. Update the visual path and default direction (moving UP from ground)
//     _robotPath = [Offset(_currentX, _currentY)];
//   }

//   void _processOdometry() {
//     if (!widget.isActive) return;

//     // SYNC WITH TELEMETRY ALTITUDE
//     // Assuming telemetry.altitude is in meters from the ground.
//     // So currentY (pixels from top) = totalHeight - altitude.
//     double newY = (_faceHeight - _telemetry.altitude).clamp(0.0, _faceHeight);

//     // Only redraw if the bot actually moved a noticeable amount
//     if ((_currentY - newY).abs() > 0.1) {
//       setState(() {
//         _currentY = newY;
//         _robotPath.add(Offset(_currentX, _currentY));

//         // Sync the true area cleaned directly from the robot's hardware telemetry
//         widget.task.areaCovered = _telemetry.areaCleaned;


//         //------------------------ Used for mock data -------------------------

//         // ── NEW: DYNAMIC AREA CALCULATION ──
//         // double completedFacesArea = (_currentFace - 1) * _faceWidth * _faceHeight;
//         // double completedStripsArea = _currentStrip * _robotCleaningWidth * _faceHeight;
//         // double currentStripArea = (_faceStartY - _currentY).abs() * _robotCleaningWidth;
        
//         // // Multiply total square meters by 10.7639 to get square feet for the UI
//         // widget.task.areaCovered = (completedFacesArea + completedStripsArea + currentStripArea) * 10.7639;


//         // // ------------------------used for mock data=============================

//         // COUNTER LOGIC
//         if (_currentY <= 0.5 && !_isAtTop) {
//           _isAtTop = true;
//           _isAtBottom = false;
//           _upCount++;
//         } else if (_currentY >= (_faceHeight - 0.5) && !_isAtBottom) {
//           _isAtBottom = true;
//           _isAtTop = false;
//           _downCount++;
//         } else if (_currentY > 0.5 && _currentY < (_faceHeight - 0.5)) {
//           _isAtTop = false;
//           _isAtBottom = false;
//         }
//       });
//     }
//   }

//   // 👉 Added thos Helper Function on 14-08-2026
//   void _loadDimensionsForFace(int face) {
//     if (_faceDimensions.containsKey(face)) {
//       _faceWidth = _faceDimensions[face]!['w']!;
//       _faceHeight = _faceDimensions[face]!['h']!;
//     } else {
//       _faceHeight = widget.task.buildingHeight > 0 ? widget.task.buildingHeight : 50.0;
//       int facesCount = widget.task.numberOfFaces != null && widget.task.numberOfFaces! > 0 
//           ? widget.task.numberOfFaces! 
//           : 1;
//       _faceWidth = (widget.task.surfaceArea / (_faceHeight * facesCount)).clamp(1.0, double.infinity);
//     }
//   }

//   void _saveAndResetCounts() {
//     _faceStripCounts[_currentFace] ??= {};
//     _faceStripCounts[_currentFace]![_currentStrip] = {
//       'up': _upCount,
//       'down': _downCount,
//     };
//     _faceSnapshot[_currentFace] = {
//       'strip': _currentStrip.toDouble(),
//       'y': _currentY,
//     };
//     _upCount = 0;
//     _downCount = 0;
//   }

//   void _restoreCounts(int face, int strip) {
//     _upCount = _faceStripCounts[face]?[strip]?['up'] ?? 0;
//     _downCount = _faceStripCounts[face]?[strip]?['down'] ?? 0;
//   }

//   String _faceName(int face) {
//     switch (face) {
//       case 1:
//         return 'FACE-1';
//       case 2:
//         return 'FACE-2';
//       case 3:
//         return 'FACE-3';
//       case 4:
//         return 'FACE-4';
//       default:
//         return 'FACE $face';
//     }
//   }

//   List<_Tab> get _currentTabs {
//     var tabs = [
//       const _Tab(
//         'TELEMETRY',
//         Icons.analytics_outlined,
//         Icons.analytics_rounded,
//       ),
//       const _Tab('VISION', Icons.videocam_outlined, Icons.videocam_rounded),
//       const _Tab('MAPPING', Icons.map_outlined, Icons.map_rounded),
//       const _Tab(
//         'STATISTICS',
//         Icons.bar_chart_outlined,
//         Icons.bar_chart_rounded,
//       ),
//       const _Tab('CONFIG', Icons.tune_outlined, Icons.tune_rounded),
//     ];

//     if (widget.task.snapshots.isNotEmpty) {
//       tabs.add(
//         const _Tab(
//           'SNAPS',
//           Icons.photo_library_outlined,
//           Icons.photo_library_rounded,
//         ),
//       );
//     }
//     if (widget.task.videos.isNotEmpty) {
//       tabs.add(
//         const _Tab(
//           'VIDEOS',
//           Icons.video_collection_outlined,
//           Icons.video_collection_rounded,
//         ),
//       );
//     }
//     if (widget.task.alerts.isNotEmpty) {
//       tabs.add(
//         const _Tab(
//           'ALERTS',
//           Icons.warning_amber_outlined,
//           Icons.warning_rounded,
//         ),
//       );
//     }
//     return tabs;
//   }

//   void _initTabController() {
//     _tabCtrl = TabController(
//       length: _currentTabs.length,
//       vsync: this,
//       initialIndex: _tab >= _currentTabs.length ? 0 : _tab,
//     );
//     _tabCtrl.addListener(() {
//       if (_tabCtrl.indexIsChanging) return;
//       setState(() => _tab = _tabCtrl.index);
//     });
//   }

//   // void _refreshTabs() {
//   //   setState(() {
//   //     _tabCtrl.dispose();
//   //     _initTabController();
//   //   });
//   // }

//   // void _refreshTabs() {
//   //   final oldCtrl = _tabCtrl;
//   //   _initTabController();
//   //   setState(() {});
//   //   // Wait until the UI is completely finished rebuilding before deleting the old controller!
//   //   WidgetsBinding.instance.addPostFrameCallback((_) {
//   //     oldCtrl.dispose();
//   //   });
//   // }

//   void _refreshTabs() {
//     final oldCtrl = _tabCtrl;
//     _initTabController();
//     setState(() {});
//     // Wait until the UI is completely finished rebuilding before deleting the old controller!
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       oldCtrl.dispose();
//     });
//   }

//   // ENCODES HISTORY SO IT PERSISTS FOREVER
//   String _buildMappingStateJson() {
//     final Map<String, dynamic> fscStringMap = {};
//     _faceStripCounts.forEach((faceKey, stripMap) {
//       final Map<String, dynamic> sMap = {};
//       stripMap.forEach((stripKey, counts) {
//         sMap[stripKey.toString()] = counts;
//       });
//       fscStringMap[faceKey.toString()] = sMap;
//     });

//     // 👉 Added THIS BLOCK on 14-08-2026
//     final Map<String, dynamic> dimsStringMap = {};
//     _faceDimensions.forEach((faceKey, dimMap) {
//       dimsStringMap[faceKey.toString()] = dimMap;
//     });

//     return jsonEncode({
//       'upCount': _upCount,
//       'downCount': _downCount,
//       'currentX': _currentX,
//       'currentY': _currentY,
//       'faceSnapshot': _faceSnapshot,
//       'faceStripCounts': fscStringMap,
//       'faceDimensions': dimsStringMap,
//     });
//   }

//   void _saveTelemetryToTask() async {
//     if (!widget.isActive) return;

//     List<AlertLog> newAlerts = [];

//     if (_telemetry.waterLvl < 10.0 && !_waterWarningPlayed) {   // changed _telemetry.waterLevel to _telemetry.waterLvl
//       _tts.speak("Warning. Water level is critically low.");
//       newAlerts.add(
//         AlertLog()
//           ..timestamp = DateTime.now()
//           ..message = "Water Level Critical (<5%)"
//           ..type = "CRITICAL",
//       );
//       _waterWarningPlayed = true;
//     }

//     if (_telemetry.batteryPct < 10.0 && !_batteryWarningPlayed) {     // changed _telemetry.batteryLevel to _telemetry.batteryPct
//       _tts.speak("Warning. Battery level low. Please return to base.");
//       newAlerts.add(
//         AlertLog()
//           ..timestamp = DateTime.now()
//           ..message = "Battery Low (<10%)"
//           ..type = "WARNING",
//       );
//       _batteryWarningPlayed = true;
//     }

//     double diffWater = _telemetry.waterUsed - _lastSavedWater;
//     double diffEnergy = _telemetry.energyConsumed - _lastSavedEnergy;

//     if (diffWater > 0 ||
//         diffEnergy > 0 ||
//         newAlerts.isNotEmpty ||
//         _robotPath.isNotEmpty) {
//       _lastSavedWater = _telemetry.waterUsed;
//       _lastSavedEnergy = _telemetry.energyConsumed;

//       final isar = IsarService.isar;
//       await isar.writeTxn(() async {
//         final latestTask = await isar.tasks.get(widget.task.id);
//         if (latestTask != null) {
//           latestTask.waterUsed = (latestTask.waterUsed) + diffWater;
//           latestTask.energyConsumed = (latestTask.energyConsumed) + diffEnergy;
          
//           // ---------------------coded during mock data testing--------------

//           latestTask.areaCovered = widget.task.areaCovered;

//           // ---------------------coded during mock data  testing ----------- 

//           latestTask.currentFace = _currentFace;
//           latestTask.currentStrip = _currentStrip;
//           latestTask.mappingState = _buildMappingStateJson();

//           if (newAlerts.isNotEmpty) {
//             latestTask.alerts = List.from(latestTask.alerts)..addAll(newAlerts);
//           }
//           latestTask.isSynced = false;
//           await isar.tasks.put(latestTask);

//           if (mounted) {
//             setState(() {
//               widget.task.waterUsed = latestTask.waterUsed;
//               widget.task.energyConsumed = latestTask.energyConsumed;
//               widget.task.alerts = latestTask.alerts;
//             });
//             if (newAlerts.isNotEmpty) _refreshTabs();
//           }
//         }
//       });
//     }
//   }

//   @override
//   void dispose() {
//     _autoSaveTimer?.cancel();
//     _saveTelemetryToTask();
//     _telemetry.removeListener(_processOdometry);
//     _telemetry.disposeConnection();
//     _telemetry.dispose();
//     _tabCtrl.dispose();
//     super.dispose();
//   }

//   Future<void> _stopMission() async {
//     ScaffoldMessenger.of(context).showSnackBar(
//       const SnackBar(content: Text('Ending mission and saving telemetry...')),
//     );
//     try {
//       _autoSaveTimer?.cancel();

//       final isar = IsarService.isar;
//       await isar.writeTxn(() async {
//         final latestTask = await isar.tasks.get(widget.task.id);
//         if (latestTask != null) {
//           latestTask.sessionDate = DateTime.now();
//           latestTask.status = "COMPLETED";
//           latestTask.currentFace = _currentFace;
//           latestTask.currentStrip = _currentStrip;
//           latestTask.mappingState = _buildMappingStateJson();
//           latestTask.isSynced = false;
//           await isar.tasks.put(latestTask);
//         }
//       });

//       _telemetry.disposeConnection();

//       if (mounted) Navigator.pop(context);
//     } catch (e) {
//       debugPrint("Failed to save mission data: $e");
//     }
//   }

//   List<SidebarItem> _sidebarItems(BuildContext ctx) => [
//     SidebarItem(
//       icon: Icons.water_drop_rounded,
//       label: 'Task List',
//       sublabel: 'Return',
//       onTap: () => Navigator.pop(ctx),
//     ),
//     if (widget.isActive)
//       SidebarItem(
//         icon: Icons.stop_circle_outlined,
//         label: 'End Mission',
//         sublabel: 'Save & Exit',
//         accent: AppTheme.red,
//         onTap: _stopMission,
//       ),
//   ];

//   @override
//   Widget build(BuildContext context) {
//     final isWide = MediaQuery.of(context).size.width >= 600;

//     return GcsScaffold(
//       screenTitle: widget.task.buildingName ?? 'Unknown',
//       screenCode: 'WIPER · #${widget.task.id.toString().padLeft(4, '0')}',
//       accentColor: widget.isActive ? AppTheme.green : AppTheme.cyan,
//       items: _sidebarItems(context),
//       activeIndex: _tab,
//       body: Column(
//         children: [
//           _TabStrip(
//             tabs: _currentTabs,
//             current: _tab,
//             isWide: isWide,
//             onTap: (i) {
//               _tabCtrl.animateTo(i);
//               setState(() => _tab = i);
//             },
//           ),
//           Expanded(
//             child: TabBarView(
//               controller: _tabCtrl,
//               physics: const BouncingScrollPhysics(),
//               children: [
//                 TelemetrySection(
//                   task: widget.task,
//                   isWide: isWide,
//                   telemetry: _telemetry,
//                 ),
//                 _VisionTab(
//                   task: widget.task,
//                   isWide: isWide,
//                   onSnapshot: (path, time, camName, isIssue, issueDesc) async {
//                     final isar = IsarService.isar;
//                     await isar.writeTxn(() async {
//                       final latestTask = await isar.tasks.get(widget.task.id);
//                       if (latestTask != null) {
//                         bool wasEmpty = latestTask.snapshots.isEmpty;
//                         latestTask.snapshots = List.from(latestTask.snapshots)
//                           ..add(
//                             TaskSnapshot()
//                               ..filePath = path
//                               ..timestamp = time
//                               ..cameraName = camName
//                               ..isIssue = isIssue
//                               ..issueDescription = issueDesc,
//                           );
//                         latestTask.isSynced = false;
//                         await isar.tasks.put(latestTask);
//                         if (mounted) {
//                           setState(
//                             () => widget.task.snapshots = latestTask.snapshots,
//                           );
//                           if (wasEmpty) _refreshTabs();
//                         }
//                       }
//                     });
//                   },
//                   onVideoRecorded: (path, time, camName) async {
//                     final isar = IsarService.isar;
//                     await isar.writeTxn(() async {
//                       final latestTask = await isar.tasks.get(widget.task.id);
//                       if (latestTask != null) {
//                         bool exists = latestTask.videos.any(
//                           (v) => v.filePath == path,
//                         );
//                         if (!exists) {
//                           bool wasEmpty = latestTask.videos.isEmpty;
//                           latestTask.videos = List.from(latestTask.videos)
//                             ..add(
//                               TaskVideo()
//                                 ..filePath = path
//                                 ..timestamp = time
//                                 ..cameraName = camName,
//                             );
//                           latestTask.isSynced = false;
//                           await isar.tasks.put(latestTask);
//                           if (mounted) {
//                             setState(
//                               () => widget.task.videos = latestTask.videos,
//                             );
//                             if (wasEmpty) _refreshTabs();
//                           }
//                         }
//                       }
//                     });
//                   },
//                 ),
//                 _MappingTab(
//                   path: _robotPath,
//                   faceWidth: _faceWidth,
//                   faceHeight: _faceHeight,
//                   currentFace: _currentFace,
//                   totalFaces: widget.task.numberOfFaces ?? 1,
//                   faceName: _faceName(_currentFace),
//                   currentStrip: _currentStrip,
//                   totalStrips: _totalStrips,
//                   currentY: _currentY,
//                   currentX: _currentX,
//                   upCount: _upCount,
//                   downCount: _downCount,
//                   stripDirectionCounts: Map<int, Map<String, int>>.from(
//                     _faceStripCounts[_currentFace] ?? {},
//                   ),
//                   botImage: _botImage,
//                   task: widget.task,
//                   // onDimensionsChanged: (w, h) async {
//                   //   // 1. Calculate the new total surface area to keep the math consistent
//                   //   int facesCount = widget.task.numberOfFaces != null && widget.task.numberOfFaces! > 0
//                   //       ? widget.task.numberOfFaces!
//                   //       : 1;
//                   //   double newSurfaceArea = w * h * facesCount;

//                   //   setState(() {
//                   //     _faceWidth = w;
//                   //     _faceHeight = h;

//                   //     // 👉 ADD: Save custom dimensions for THIS specific face
//                   //     _faceDimensions[_currentFace] = {'w': w, 'h': h};
                      
//                   //     _currentStrip = 0;
//                   //     // Note: Do NOT reset _currentFace to 1 here, so we stay on the face we are editing!

//                   //     _currentStrip = 0;
//                   //     // _currentFace = 1;
//                   //     // _faceStripCounts = {};
//                   //     // _faceSnapshot = {};

//                   //     _faceStripCounts[_currentFace] = {}; 
//                   //     _faceSnapshot.remove(_currentFace);
//                   //     _upCount = 0;
//                   //     _downCount = 0;

//                   //     // Update the local task object in memory
//                   //     widget.task.surfaceArea = newSurfaceArea;
//                   //     widget.task.buildingHeight = h;

//                   //     _resetToBottom();
//                   //   });

//                   //   // 2. Save the NEW values permanently to the Isar Database
//                   //   final isar = IsarService.isar;
//                   //   await isar.writeTxn(() async {
//                   //     final latestTask = await isar.tasks.get(widget.task.id);
//                   //     if (latestTask != null) {
//                   //       // latestTask.surfaceArea = widget.task.surfaceArea;
//                   //       // latestTask.buildingHeight = widget.task.buildingHeight;
//                   //       latestTask.currentStrip = _currentStrip;
//                   //       latestTask.currentFace = _currentFace;
//                   //       latestTask.mappingState = _buildMappingStateJson();
//                   //       await isar.tasks.put(latestTask);
//                   //     }
//                   //   });
//                   // },

//                   onDimensionsChanged: (w, h) async {
//                     int facesCount = widget.task.numberOfFaces != null && widget.task.numberOfFaces! > 0
//                         ? widget.task.numberOfFaces!
//                         : 1;
//                     double newSurfaceArea = w * h * facesCount;

//                     setState(() {
//                       _faceWidth = w;
//                       _faceHeight = h;
//                       _faceDimensions[_currentFace] = {'w': w, 'h': h};
                      
//                       _currentStrip = 0;
//                       _faceStripCounts[_currentFace] = {}; 
//                       _faceSnapshot.remove(_currentFace);
//                       _upCount = 0;
//                       _downCount = 0;

//                       widget.task.surfaceArea = newSurfaceArea;
//                       widget.task.buildingHeight = h;

//                       _resetToBottom();
//                     });

//                     final isar = IsarService.isar;
//                     await isar.writeTxn(() async {
//                       final latestTask = await isar.tasks.get(widget.task.id);
//                       if (latestTask != null) {
//                         latestTask.currentStrip = _currentStrip;
//                         latestTask.currentFace = _currentFace;
                        
//                         // 👉 CRITICAL FIX: Update Isar AND local RAM object!
//                         String newJson = _buildMappingStateJson();
//                         latestTask.mappingState = newJson; 
//                         widget.task.mappingState = newJson; // Sync RAM
                        
//                         await isar.tasks.put(latestTask);
//                       }
//                     });
//                   },

//                   // did the above change on 14-08-2026

//                   onNextStretch: () async {
//                     setState(() {
//                       _faceStripCounts[_currentFace] ??= {};
//                       _faceStripCounts[_currentFace]![_currentStrip] = {
//                         'up': _upCount,
//                         'down': _downCount,
//                       };

//                       final int totalS = (_faceWidth / _robotCleaningWidth)
//                           .floor();
//                       final double stripWidth = totalS > 0
//                           ? _faceWidth / totalS
//                           : _faceWidth;

//                       _currentStrip++;
//                       widget.task.currentStrip = _currentStrip;

//                       if (_currentStrip >= totalS) {
//                         if (_currentFace < (widget.task.numberOfFaces ?? 1)) {
//                           _currentFace++;
//                           _currentStrip = 0;
//                           widget.task.currentFace = _currentFace;
//                           widget.task.currentStrip = 0;
//                           _restoreCounts(_currentFace, _currentStrip);
//                           _resetToBottom();
//                         } else {
//                           _currentStrip = totalS > 0 ? totalS - 1 : 0;
//                           showDialog(
//                             context: context,
//                             builder: (ctx) => AlertDialog(
//                               backgroundColor: AppTheme.bgPanel,
//                               title: Text(
//                                 'Mission Complete!',
//                                 style: TextStyle(color: AppTheme.green),
//                               ),
//                               content: Text(
//                                 'All faces and strips have been completed.',
//                                 style: TextStyle(color: AppTheme.textHi),
//                               ),
//                               actions: [
//                                 TextButton(
//                                   onPressed: () => Navigator.pop(ctx),
//                                   child: Text(
//                                     'OK',
//                                     style: TextStyle(color: AppTheme.cyan),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           );
//                         }
//                       } else {
//                         _currentX =
//                             (_currentStrip * stripWidth) + (stripWidth / 2);
//                         _robotPath = [Offset(_currentX, _currentY)];
//                         _restoreCounts(_currentFace, _currentStrip);
//                       }
//                     });
//                     final isar = IsarService.isar;
//                     await isar.writeTxn(() async {
//                       final latestTask = await isar.tasks.get(widget.task.id);
//                       if (latestTask != null) {
//                         latestTask.currentStrip = _currentStrip;
//                         latestTask.currentFace = _currentFace;
//                         latestTask.mappingState = _buildMappingStateJson();
//                         await isar.tasks.put(latestTask);
//                       }
//                     });
//                   },
//                   onPrevStretch: () async {
//                     setState(() {
//                       _faceStripCounts[_currentFace] ??= {};
//                       _faceStripCounts[_currentFace]![_currentStrip] = {
//                         'up': _upCount,
//                         'down': _downCount,
//                       };

//                       if (_currentStrip > 0) {
//                         _currentStrip--;
//                         widget.task.currentStrip = _currentStrip;
//                         final int totalS = (_faceWidth / _robotCleaningWidth)
//                             .floor();
//                         final double stripWidth = totalS > 0
//                             ? _faceWidth / totalS
//                             : _faceWidth;
//                         _currentX =
//                             (_currentStrip * stripWidth) + (stripWidth / 2);
//                         _robotPath = [Offset(_currentX, _currentY)];
//                         _restoreCounts(_currentFace, _currentStrip);
//                       } else if (_currentFace > 1) {
//                         _currentFace--;
//                         widget.task.currentFace = _currentFace;
//                         final int totalS = (_faceWidth / _robotCleaningWidth)
//                             .floor();
//                         final double stripWidth = totalS > 0
//                             ? _faceWidth / totalS
//                             : _faceWidth;
//                         _currentStrip = totalS > 0 ? totalS - 1 : 0;
//                         widget.task.currentStrip = _currentStrip;
//                         _currentX =
//                             (_currentStrip * stripWidth) + (stripWidth / 2);
//                         _robotPath = [Offset(_currentX, _currentY)];

//                         // // --------coded for mock data testing--------------

//                         // _faceStartY = _currentY; 

//                         // // --------coded during mock data testing--------------
//                         _restoreCounts(_currentFace, _currentStrip);
//                       }
//                     });
//                     final isar = IsarService.isar;
//                     await isar.writeTxn(() async {
//                       final latestTask = await isar.tasks.get(widget.task.id);
//                       if (latestTask != null) {
//                         latestTask.currentStrip = _currentStrip;
//                         latestTask.currentFace = _currentFace;
//                         latestTask.mappingState = _buildMappingStateJson();
//                         await isar.tasks.put(latestTask);
//                       }
//                     });
//                   },
//                   onNextFace: () async {
//                     setState(() {
//                       if (_currentFace < (widget.task.numberOfFaces ?? 1)) {
//                         // 1. Save current face progress
//                         _saveAndResetCounts();

//                         // 2. Advance face
//                         _currentFace++;
//                         widget.task.currentFace = _currentFace;
//                         _currentStrip = 0;

//                         // 👉 ADD: Load custom dimensions for the new face
//                         _loadDimensionsForFace(_currentFace);

//                         // 3. Reset bot to bottom-center of new face
//                         _resetToBottom();
//                         _restoreCounts(_currentFace, _currentStrip);
//                         _robotPath = [Offset(_currentX, _currentY)];
//                       }
//                     });

//                     // 4. Persistent Save
//                     final isar = IsarService.isar;
//                     await isar.writeTxn(() async {
//                       final latestTask = await isar.tasks.get(widget.task.id);
//                       if (latestTask != null) {
//                         latestTask.currentStrip = _currentStrip;
//                         latestTask.currentFace = _currentFace;
//                         latestTask.mappingState =
//                             _buildMappingStateJson(); // Saving the history
//                         await isar.tasks.put(latestTask);
//                       }
//                     });
//                   },

//                   // onPrevFace: () async {
//                   //   setState(() {
//                   //     if (_currentFace > 1) {
//                   //       _saveAndResetCounts();
//                   //       _currentFace--;
//                   //       widget.task.currentFace = _currentFace;
//                   //       _currentStrip = 0;
//                   //       _resetToBottom();
//                   //       _restoreCounts(_currentFace, _currentStrip);
//                   //       _robotPath = [];
//                   //     }
//                   //   });
//                   //   final isar = IsarService.isar;
//                   //   await isar.writeTxn(() async {
//                   //     final latestTask = await isar.tasks.get(widget.task.id);
//                   //     if (latestTask != null) {
//                   //       latestTask.currentStrip = _currentStrip;
//                   //       latestTask.currentFace = _currentFace;
//                   //       latestTask.mappingState = _buildMappingStateJson();
//                   //       await isar.tasks.put(latestTask);
//                   //     }
//                   //   });
//                   // },
//                   onPrevFace: () async {
//                     setState(() {
//                       if (_currentFace > 1) {
//                         // 1. Save current state
//                         _saveAndResetCounts();

//                         // 2. Go back
//                         _currentFace--;
//                         widget.task.currentFace = _currentFace;

//                         // 👉 ADD: Load custom dimensions for the previous face
//                         _loadDimensionsForFace(_currentFace);

//                         // 3. Restore last known position (X, Y, Strip) from the snapshot
//                         final snap = _faceSnapshot[_currentFace];
//                         if (snap != null) {
//                           _currentStrip = snap['strip']!.toInt();
//                           _currentY = snap['y']!;
//                           final int totalS = (_faceWidth / _robotCleaningWidth)
//                               .floor();
//                           final double stripWidth = totalS > 0
//                               ? _faceWidth / totalS
//                               : _faceWidth;
//                           _currentX =
//                               (_currentStrip * stripWidth) + (stripWidth / 2);
//                         } else {
//                           // Fallback if no snapshot
//                           _currentStrip = 0;
//                           _resetToBottom();
//                         }
//                         _restoreCounts(_currentFace, _currentStrip);
//                         _robotPath = [Offset(_currentX, _currentY)];

//                         // // -----------coded for mock data testing----------------

//                         // _faceStartY = _currentY;

//                         // // -----------coded during mock data testing----------------
//                       }
//                     });

//                     final isar = IsarService.isar;
//                     await isar.writeTxn(() async {
//                       final latestTask = await isar.tasks.get(widget.task.id);
//                       if (latestTask != null) {
//                         latestTask.currentStrip = _currentStrip;
//                         latestTask.currentFace = _currentFace;
//                         latestTask.mappingState = _buildMappingStateJson();
//                         await isar.tasks.put(latestTask);
//                       }
//                     });
//                   },

//                   // onNextFace: () async {
//                   //   setState(() {
//                   //     if (_currentFace < (widget.task.numberOfFaces ?? 1)) {
//                   //       _saveAndResetCounts();
//                   //       _currentFace++;
//                   //       widget.task.currentFace = _currentFace;
//                   //       _currentStrip = 0;
//                   //       _resetToBottom();
//                   //       _restoreCounts(_currentFace, _currentStrip);
//                   //       _robotPath = [];
//                   //     }
//                   //   });
//                   //   final isar = IsarService.isar;
//                   //   await isar.writeTxn(() async {
//                   //     final latestTask = await isar.tasks.get(widget.task.id);
//                   //     if (latestTask != null) {
//                   //       latestTask.currentStrip = _currentStrip;
//                   //       latestTask.currentFace = _currentFace;
//                   //       latestTask.mappingState = _buildMappingStateJson();
//                   //       await isar.tasks.put(latestTask);
//                   //     }
//                   //   });
//                   // },
//                 ),
//                 _StatisticsTab(
//                   task: widget.task,
//                   isWide: isWide,
//                   telemetry: _telemetry,
//                   isActive: widget.isActive,
//                   lastSavedWater: _lastSavedWater,
//                   trueAreaCleaned: widget.task.areaCovered,
//                   lastSavedEnergy: _lastSavedEnergy,
//                                     // fl chart
//                   lastSavedWaterFl: _lastSavedWater,
//                   lastSavedAreaFl: widget.task.areaCovered,
//                   lastSavedEnergyFl: _lastSavedEnergy,
//                 ),
//                 _ConfigTab(
//                   task: widget.task,
//                   onTaskUpdated: () => setState(() {}),
//                 ),
//                 if (widget.task.snapshots.isNotEmpty)
//                   _SnapsTab(task: widget.task),
//                 if (widget.task.videos.isNotEmpty)
//                   _VideosTab(task: widget.task),
//                 if (widget.task.alerts.isNotEmpty)
//                   _AlertsTab(task: widget.task),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// class _Tab {
//   final String label;
//   final IconData icon;
//   final IconData activeIcon;
//   const _Tab(this.label, this.icon, this.activeIcon);
// }

// class _TabStrip extends StatelessWidget {
//   final List<_Tab> tabs;
//   final int current;
//   final bool isWide;
//   final void Function(int) onTap;
//   const _TabStrip({
//     required this.tabs,
//     required this.current,
//     required this.isWide,
//     required this.onTap,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       height: isWide ? 48 : 52,
//       color: AppTheme.bgPanel,
//       child: Row(
//         children: List.generate(tabs.length, (i) {
//           final active = i == current;
//           final t = tabs[i];
//           return Expanded(
//             child: GestureDetector(
//               onTap: () => onTap(i),
//               child: AnimatedContainer(
//                 duration: const Duration(milliseconds: 200),
//                 height: double.infinity,
//                 decoration: BoxDecoration(
//                   color: active ? AppTheme.cyanFaint : Colors.transparent,
//                   border: Border(
//                     bottom: BorderSide(
//                       color: active ? AppTheme.cyan : AppTheme.borderDim,
//                       width: active ? 2 : 1,
//                     ),
//                   ),
//                 ),
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Icon(
//                       active ? t.activeIcon : t.icon,
//                       size: 15,
//                       color: active ? AppTheme.cyan : AppTheme.textLo,
//                     ),
//                     const SizedBox(height: 2),
//                     Text(
//                       t.label,
//                       style: GoogleFonts.jetBrainsMono(
//                         fontSize: 8,
//                         fontWeight: active ? FontWeight.w700 : FontWeight.w400,
//                         color: active ? AppTheme.cyan : AppTheme.textLo,
//                         letterSpacing: 0.8,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           );
//         }),
//       ),
//     );
//   }
// }

// class _VisionTab extends StatefulWidget {
//   final Task task;
//   final bool isWide;
//   final Function(String, DateTime, String, bool, String)? onSnapshot;
//   final Function(String, DateTime, String)? onVideoRecorded;

//   const _VisionTab({
//     required this.task,
//     required this.isWide,
//     this.onSnapshot,
//     this.onVideoRecorded,
//   });

//   @override
//   State<_VisionTab> createState() => _VisionTabState();
// }

// class _VisionTabState extends State<_VisionTab>
//     with AutomaticKeepAliveClientMixin {
//   @override
//   bool get wantKeepAlive => true;

//   @override
//   Widget build(BuildContext context) {
//     super.build(context);
//     final pad = AppTheme.screenPad(context);
//     final h = MediaQuery.of(context).size.width >= 600 ? 300.0 : 200.0;
//     final safeTaskName = widget.task.buildingName ?? 'Unknown_Task';

//     return SingleChildScrollView(
//       padding: EdgeInsets.symmetric(horizontal: pad, vertical: 16),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           GcsSectionLabel('Live Feeds (RTSP)'),
//           const SizedBox(height: 12),
//           SizedBox(
//             height: h,
//             child: CameraView(
//               label: 'CAMERA A',
//               url: widget.task.cameraALink,
//               taskName: safeTaskName,
//               faceNumber: widget.task.currentFace,
//               onSnapshot: widget.onSnapshot,
//               onVideoRecorded: widget.onVideoRecorded,
//             ),
//           ),
//           const SizedBox(height: 16),
//           SizedBox(
//             height: h,
//             child: CameraView(
//               label: 'CAMERA B',
//               url: widget.task.cameraBLink,
//               taskName: safeTaskName,
//               faceNumber: widget.task.currentFace,
//               onSnapshot: widget.onSnapshot,
//               onVideoRecorded: widget.onVideoRecorded,
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// class _StatisticsTab extends StatelessWidget {
//   final Task task;
//   final bool isWide;
//   final bool isActive;
//   final WiperTelemetry telemetry;
//   final double lastSavedWater;
//   final double trueAreaCleaned;
//   final double lastSavedEnergy;
//     // fl chart
//   final double lastSavedWaterFl;
//   final double lastSavedAreaFl;
//   final double lastSavedEnergyFl;
  

//   const _StatisticsTab({
//     required this.task,
//     required this.isWide,
//     required this.telemetry,
//     required this.isActive,
//     required this.lastSavedWater,
//     required this.trueAreaCleaned,
//     required this.lastSavedEnergy,   
//      // fl chart
//     required this.lastSavedWaterFl,
//     required this.lastSavedAreaFl,
//     required this.lastSavedEnergyFl,
//   });

//   @override
//   Widget build(BuildContext context) {
//     final pad = AppTheme.screenPad(context);

//     return AnimatedBuilder(
//       animation: telemetry,
//       builder: (context, _) {
//         final t = telemetry;
//         double safeWater = task.waterUsed;
//         double safeEnergy = task.energyConsumed;

//         Widget statsWrap = Wrap(
//           spacing: 12,
//           runSpacing: 12,
//           children: [
//             MicroTeleTile(
//               label: 'WATER USED',
//               value: isActive
//                   ? (safeWater + (t.waterUsed - lastSavedWater))
//                         .toStringAsFixed(1)
//                   : safeWater.toStringAsFixed(1),
//               unit: 'L',
//               icon: Icons.water_drop_outlined,
//               color: AppTheme.cyan,
//             ),
//             MicroTeleTile(
//               label: 'ENERGY CONSUMED',
//               value: isActive
//                   ? (safeEnergy + (t.energyConsumed - lastSavedEnergy))
//                         .toStringAsFixed(1)
//                   : safeEnergy.toStringAsFixed(1),
//               unit: 'kWh',
//               icon: Icons.bolt_rounded,
//               color: AppTheme.amber,
//             ),
//             MicroTeleTile(
//               label: 'AREA CLEANED',
//               value: trueAreaCleaned.toStringAsFixed(0),
//               unit: 'sqft',
//               icon: Icons.square_foot_rounded,
//               color: AppTheme.green,
//             ),
//           ],
//         );

//         Widget chartsColumn = Column(
//           children: [
//             _ChartCard(
//               title: 'AREA CLEANED vs TIME (sqft / hr)',
//               color: AppTheme.green,
//               maxY: 1500,
//                             // fl chart
//               spots: task.areaHistoryPersisted.map((p) => FlSpot(p.hour, p.value)).toList(),
//             ),
//             const SizedBox(height: 12),
//             _ChartCard(
//               title: 'WATER USED vs TIME (L / hr)',
//               color: AppTheme.cyan,
//               maxY: 100,
//                             // fl chart
//               spots: task.waterHistoryPersisted.map((p) => FlSpot(p.hour, p.value)).toList(),
//             ),
//             const SizedBox(height: 12),
//             _ChartCard(
//               title: 'ENERGY CONSUMED vs TIME (kWh / hr)',
//               color: AppTheme.amber,
//               maxY: 3000,
//               // spots: t.energyHistory,
//               spots: task.energyHistoryPersisted.map((p) => FlSpot(p.hour, p.value)).toList(),
//             ),
//           ],
//         );

//         return SingleChildScrollView(
//           padding: EdgeInsets.symmetric(horizontal: pad, vertical: 16),
//           child: isWide
//               ? Row(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Expanded(
//                       flex: 2,
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           GcsSectionLabel('Session Totals'),
//                           const SizedBox(height: 12),
//                           statsWrap,
//                         ],
//                       ),
//                     ),
//                     const SizedBox(width: 20),
//                     Expanded(
//                       flex: 3,
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           GcsSectionLabel('Performance Analytics'),
//                           const SizedBox(height: 12),
//                           chartsColumn,
//                         ],
//                       ),
//                     ),
//                   ],
//                 )
//               : Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     GcsSectionLabel('Session Totals'),
//                     const SizedBox(height: 12),
//                     statsWrap,
//                     const SizedBox(height: 24),
//                     GcsSectionLabel('Performance Analytics'),
//                     const SizedBox(height: 12),
//                     chartsColumn,
//                   ],
//                 ),
//         );
//       },
//     );
//   }
// }

// class _ChartCard extends StatelessWidget {
//   final String title;
//   final Color color;
//   final double maxY;
//   final List<FlSpot> spots;
//   const _ChartCard({
//     required this.title,
//     required this.color,
//     required this.maxY,
//     required this.spots,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       height: 200,
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: AppTheme.bgCard,
//         borderRadius: BorderRadius.circular(8),
//         border: Border.all(color: AppTheme.borderDim),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Text(
//             title,
//             style: GoogleFonts.jetBrainsMono(
//               fontSize: 9,
//               color: AppTheme.textMid,
//               letterSpacing: 1,
//             ),
//           ),
//           const SizedBox(height: 16),
//           Expanded(
//             child: LineChart(
//               LineChartData(
//                 gridData: FlGridData(
//                   show: true,
//                   drawVerticalLine: false,
//                   getDrawingHorizontalLine: (value) =>
//                       FlLine(color: AppTheme.borderDim, strokeWidth: 1),
//                 ),
//                 titlesData: FlTitlesData(
//                   leftTitles: AxisTitles(
//                     sideTitles: SideTitles(
//                       showTitles: true,
//                       reservedSize: 40,
//                       getTitlesWidget: (val, meta) => Text(
//                         val.toInt().toString(),
//                         style: GoogleFonts.jetBrainsMono(
//                           fontSize: 8,
//                           color: AppTheme.textLo,
//                         ),
//                       ),
//                     ),
//                   ),
//                   bottomTitles: AxisTitles(
//                     sideTitles: SideTitles(
//                       showTitles: true,
//                       reservedSize: 22,
//                       getTitlesWidget: (val, meta) => Text(
//                         '${val.toInt()}h',
//                         style: GoogleFonts.jetBrainsMono(
//                           fontSize: 8,
//                           color: AppTheme.textLo,
//                         ),
//                       ),
//                     ),
//                   ),
//                   topTitles: const AxisTitles(
//                     sideTitles: SideTitles(showTitles: false),
//                   ),
//                   rightTitles: const AxisTitles(
//                     sideTitles: SideTitles(showTitles: false),
//                   ),
//                 ),
//                 borderData: FlBorderData(show: false),
//                 minX: 0,
//                 maxX: 12,
//                 minY: 0,
//                 maxY: maxY,
//                 lineBarsData: [
//                   LineChartBarData(
//                     // spots: const [
//                     //   FlSpot(0, 0),
//                     //   FlSpot(2, 0.2),
//                     //   FlSpot(5, 0.4),
//                     //   FlSpot(8, 0.7),
//                     //   FlSpot(12, 0.9),
//                     // ].map((s) => FlSpot(s.x, s.y * maxY)).toList(),
//                     spots: spots.isNotEmpty ? spots : const [FlSpot(0, 0)],
//                     isCurved: true,
//                     color: color,
//                     barWidth: 2,
//                     isStrokeCapRound: true,
//                     dotData: const FlDotData(show: false),
//                     belowBarData: BarAreaData(
//                       show: true,
//                       color: color.withOpacity(0.1),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// class _MappingTab extends StatelessWidget {
//   final List<Offset> path;
//   final double faceWidth;
//   final double faceHeight;
//   final int currentFace;
//   final int totalFaces;
//   final String faceName;
//   final int currentStrip;
//   final int totalStrips;
//   final double currentY;
//   final double currentX;
//   final Task task;
//   final VoidCallback onNextStretch;
//   final VoidCallback onPrevStretch;
//   final VoidCallback onNextFace;
//   final VoidCallback onPrevFace;
//   final Function(double, double) onDimensionsChanged;
//   final int upCount;
//   final int downCount;

//   final Map<int, Map<String, int>> stripDirectionCounts;
//   final ui.Image? botImage;

//   const _MappingTab({
//     required this.path,
//     required this.faceWidth,
//     required this.faceHeight,
//     required this.currentFace,
//     required this.totalFaces,
//     required this.faceName,
//     required this.currentStrip,
//     required this.totalStrips,
//     required this.currentY,
//     required this.currentX,
//     required this.task,
//     required this.onNextStretch,
//     required this.onPrevStretch,
//     required this.onNextFace,
//     required this.onPrevFace,
//     required this.onDimensionsChanged,
//     required this.upCount,
//     required this.downCount,
//     required this.stripDirectionCounts,
//     required this.botImage,
//   });

//   double _faceProgress() {
//     if (totalStrips <= 0) return 0;
//     return (currentStrip / totalStrips * 100).clamp(0, 100);
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.all(12.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           // 👉 NEW COMPACT HEADER (No manual up/down arrows, no text on stretch buttons)
//           Container(
//             padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
//             decoration: BoxDecoration(
//               color: AppTheme.bgCard,
//               borderRadius: BorderRadius.circular(8),
//               border: Border.all(color: AppTheme.borderDim),
//             ),
//             child: SingleChildScrollView(
//               scrollDirection: Axis.horizontal,
//               child: Row(
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 children: [
//                   GcsSectionLabel('Trajectory'),
//                   const SizedBox(width: 12),

//                   _FaceInputButton(
//                     faceName: faceName,
//                     currentFace: currentFace,
//                     totalFaces: totalFaces,
//                     faceProgress: _faceProgress(),
//                     faceWidth: faceWidth,
//                     faceHeight: faceHeight,
//                     onDimensionsChanged: onDimensionsChanged,
//                     onPrevFace: onPrevFace,
//                     onNextFace: onNextFace,
//                   ),

//                   const SizedBox(width: 8),

//                   Container(
//                     padding: const EdgeInsets.symmetric(
//                       horizontal: 8,
//                       vertical: 4,
//                     ),
//                     decoration: BoxDecoration(
//                       color: AppTheme.amber.withOpacity(0.15),
//                       borderRadius: BorderRadius.circular(4),
//                     ),
//                     child: Text(
//                       'STRIP ${currentStrip + 1}/$totalStrips',
//                       style: GoogleFonts.jetBrainsMono(
//                         fontSize: 10,
//                         fontWeight: FontWeight.bold,
//                         color: AppTheme.amber,
//                       ),
//                     ),
//                   ),

//                   const SizedBox(width: 16),

//                   Text(
//                     '↑$upCount ↓$downCount',
//                     style: GoogleFonts.jetBrainsMono(
//                       color: AppTheme.green,
//                       fontWeight: FontWeight.bold,
//                       fontSize: 14,
//                     ),
//                   ),

//                   const SizedBox(width: 16),

//                   IconButton(
//                     icon: const Icon(
//                       Icons.arrow_back_ios_rounded,
//                       size: 20,
//                       color: Colors.white,
//                     ),
//                     onPressed: onPrevStretch,
//                     tooltip: "Previous Stretch",
//                     constraints: const BoxConstraints(),
//                     padding: const EdgeInsets.symmetric(
//                       horizontal: 8,
//                       vertical: 6,
//                     ),
//                   ),

//                   IconButton(
//                     icon: const Icon(
//                       Icons.arrow_forward_ios_rounded,
//                       size: 20,
//                       color: Colors.white,
//                     ),
//                     onPressed: onNextStretch,
//                     tooltip: "Next Stretch",
//                     constraints: const BoxConstraints(),
//                     padding: const EdgeInsets.symmetric(
//                       horizontal: 8,
//                       vertical: 6,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),

//           const SizedBox(height: 12),

//           Expanded(
//             child: Column(
//               children: [
//                 Expanded(
//                   child: Row(
//                     crossAxisAlignment: CrossAxisAlignment.stretch,
//                     children: [
//                       Container(
//                         width: 28,
//                         alignment: Alignment.center,
//                         child: RotatedBox(
//                           quarterTurns: 3,
//                           child: Text(
//                             'height: ${faceHeight.toStringAsFixed(0)}m',
//                             style: GoogleFonts.jetBrainsMono(
//                               fontSize: 11,
//                               color: AppTheme.cyan,
//                               letterSpacing: 1.5,
//                             ),
//                           ),
//                         ),
//                       ),
//                       Expanded(
//                         child: LayoutBuilder(
//                           builder: (context, constraints) {
//                             final size = Size(
//                               constraints.maxWidth,
//                               constraints.maxHeight,
//                             );

//                             final altitude = faceHeight - currentY;
//                             final pct = (altitude / faceHeight * 100).clamp(
//                               0.0,
//                               100.0,
//                             );
//                             final widthCoveredPct = (currentX / faceWidth * 100)
//                                 .clamp(0.0, 100.0);
//                             final widthRemaining = (faceWidth - currentX).clamp(
//                               0.0,
//                               faceWidth,
//                             );

//                             // Canvas is scrollable horizontally with fixed 50px strip width
//                             final double fixedStripWidthPx = 50.0;
//                             final double canvasWidth = max(
//                               size.width,
//                               totalStrips * fixedStripWidthPx,
//                             );

//                             return Stack(
//                               children: [
//                                 Container(
//                                   width: double.infinity,
//                                   height: double.infinity,
//                                   decoration: BoxDecoration(
//                                     color: AppTheme.bgCard,
//                                     border: Border.all(
//                                       color: AppTheme.borderDim,
//                                     ),
//                                     borderRadius: BorderRadius.circular(8),
//                                   ),
//                                   child: ClipRect(
//                                     child: SingleChildScrollView(
//                                       scrollDirection: Axis.horizontal,
//                                       child: SizedBox(
//                                         width: canvasWidth,
//                                         height: size.height,
//                                         child: CustomPaint(
//                                           painter: _RobotPathPainter(
//                                             points: path,
//                                             faceWidth: faceWidth,
//                                             faceHeight: faceHeight,
//                                             currentStrip: currentStrip,
//                                             totalStrips: totalStrips,
//                                             currentY: currentY,
//                                             stripWidthPx: fixedStripWidthPx,
//                                             stripDirectionCounts:
//                                                 stripDirectionCounts,
//                                             upCount: upCount,
//                                             downCount: downCount,
//                                             botImage: botImage,
//                                           ),
//                                           size: Size(canvasWidth, size.height),
//                                         ),
//                                       ),
//                                     ),
//                                   ),
//                                 ),

//                                 Positioned(
//                                   top: 16,
//                                   right: 16,
//                                   child: Container(
//                                     padding: const EdgeInsets.symmetric(
//                                       horizontal: 12,
//                                       vertical: 10,
//                                     ),
//                                     decoration: BoxDecoration(
//                                       color: AppTheme.bgCard.withOpacity(0.9),
//                                       borderRadius: BorderRadius.circular(8),
//                                       border: Border.all(
//                                         color: AppTheme.cyan.withOpacity(0.6),
//                                       ),
//                                     ),
//                                     child: Column(
//                                       crossAxisAlignment:
//                                           CrossAxisAlignment.start,
//                                       mainAxisSize: MainAxisSize.min,
//                                       children: [
//                                         Row(
//                                           mainAxisSize: MainAxisSize.min,
//                                           crossAxisAlignment:
//                                               CrossAxisAlignment.start,
//                                           children: [
//                                             Column(
//                                               crossAxisAlignment:
//                                                   CrossAxisAlignment.start,
//                                               children: [
//                                                 Text(
//                                                   'ALTITUDE',
//                                                   style:
//                                                       GoogleFonts.jetBrainsMono(
//                                                         fontSize: 9,
//                                                         color: AppTheme.textMid,
//                                                         letterSpacing: 1.2,
//                                                       ),
//                                                 ),
//                                                 const SizedBox(height: 4),
//                                                 Row(
//                                                   mainAxisSize:
//                                                       MainAxisSize.min,
//                                                   crossAxisAlignment:
//                                                       CrossAxisAlignment
//                                                           .baseline,
//                                                   textBaseline:
//                                                       TextBaseline.alphabetic,
//                                                   children: [
//                                                     Text(
//                                                       altitude.toStringAsFixed(
//                                                         1,
//                                                       ),
//                                                       style:
//                                                           GoogleFonts.jetBrainsMono(
//                                                             fontSize: 22,
//                                                             fontWeight:
//                                                                 FontWeight.bold,
//                                                             color:
//                                                                 AppTheme.amber,
//                                                           ),
//                                                     ),
//                                                     const SizedBox(width: 4),
//                                                     Text(
//                                                       'm',
//                                                       style:
//                                                           GoogleFonts.jetBrainsMono(
//                                                             fontSize: 11,
//                                                             color: AppTheme
//                                                                 .textMid,
//                                                           ),
//                                                     ),
//                                                   ],
//                                                 ),
//                                               ],
//                                             ),
//                                             Container(
//                                               width: 1,
//                                               height: 48,
//                                               color: AppTheme.cyan.withOpacity(
//                                                 0.3,
//                                               ),
//                                               margin:
//                                                   const EdgeInsets.symmetric(
//                                                     horizontal: 12,
//                                                   ),
//                                             ),
//                                             Column(
//                                               crossAxisAlignment:
//                                                   CrossAxisAlignment.start,
//                                               children: [
//                                                 Text(
//                                                   'WIDTH',
//                                                   style:
//                                                       GoogleFonts.jetBrainsMono(
//                                                         fontSize: 9,
//                                                         color: AppTheme.textMid,
//                                                         letterSpacing: 1.2,
//                                                       ),
//                                                 ),
//                                                 const SizedBox(height: 4),
//                                                 Row(
//                                                   mainAxisSize:
//                                                       MainAxisSize.min,
//                                                   crossAxisAlignment:
//                                                       CrossAxisAlignment
//                                                           .baseline,
//                                                   textBaseline:
//                                                       TextBaseline.alphabetic,
//                                                   children: [
//                                                     Text(
//                                                       currentX.toStringAsFixed(
//                                                         1,
//                                                       ),
//                                                       style:
//                                                           GoogleFonts.jetBrainsMono(
//                                                             fontSize: 22,
//                                                             fontWeight:
//                                                                 FontWeight.bold,
//                                                             color:
//                                                                 AppTheme.cyan,
//                                                           ),
//                                                     ),
//                                                     const SizedBox(width: 4),
//                                                     Text(
//                                                       'm',
//                                                       style:
//                                                           GoogleFonts.jetBrainsMono(
//                                                             fontSize: 11,
//                                                             color: AppTheme
//                                                                 .textMid,
//                                                           ),
//                                                     ),
//                                                   ],
//                                                 ),
//                                               ],
//                                             ),
//                                           ],
//                                         ),
//                                         const SizedBox(height: 6),
//                                         Row(
//                                           mainAxisSize: MainAxisSize.min,
//                                           children: [
//                                             Column(
//                                               crossAxisAlignment:
//                                                   CrossAxisAlignment.start,
//                                               children: [
//                                                 Text(
//                                                   '${pct.toStringAsFixed(0)}% from roof',
//                                                   style:
//                                                       GoogleFonts.jetBrainsMono(
//                                                         fontSize: 9,
//                                                         color: AppTheme.cyan,
//                                                       ),
//                                                 ),
//                                                 Text(
//                                                   '↓ ${currentY.toStringAsFixed(1)}m from top',
//                                                   style:
//                                                       GoogleFonts.jetBrainsMono(
//                                                         fontSize: 9,
//                                                         color: AppTheme.textMid,
//                                                       ),
//                                                 ),
//                                               ],
//                                             ),
//                                             const SizedBox(width: 20),
//                                             Column(
//                                               crossAxisAlignment:
//                                                   CrossAxisAlignment.start,
//                                               children: [
//                                                 Text(
//                                                   '${widthCoveredPct.toStringAsFixed(0)}% covered',
//                                                   style:
//                                                       GoogleFonts.jetBrainsMono(
//                                                         fontSize: 9,
//                                                         color: AppTheme.cyan,
//                                                       ),
//                                                 ),
//                                                 Text(
//                                                   '← ${widthRemaining.toStringAsFixed(1)}m left',
//                                                   style:
//                                                       GoogleFonts.jetBrainsMono(
//                                                         fontSize: 9,
//                                                         color: AppTheme.textMid,
//                                                       ),
//                                                 ),
//                                               ],
//                                             ),
//                                           ],
//                                         ),
//                                       ],
//                                     ),
//                                   ),
//                                 ),
//                               ],
//                             );
//                           },
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//                 Container(
//                   height: 28,
//                   margin: const EdgeInsets.only(left: 28),
//                   alignment: Alignment.center,
//                   decoration: BoxDecoration(
//                     border: Border(top: BorderSide(color: AppTheme.borderDim)),
//                   ),
//                   child: Text(
//                     'width: ${faceWidth.toStringAsFixed(1)}m',
//                     style: GoogleFonts.jetBrainsMono(
//                       fontSize: 11,
//                       color: AppTheme.amber,
//                       letterSpacing: 1.5,
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// class _RobotPathPainter extends CustomPainter {
//   final List<Offset> points;
//   final double faceWidth;
//   final double faceHeight;
//   final int currentStrip;
//   final int totalStrips;
//   final double currentY;
//   final double stripWidthPx;
//   final Map<int, Map<String, int>> stripDirectionCounts;
//   final int upCount;
//   final int downCount;
//   final ui.Image? botImage;

//   _RobotPathPainter({
//     required this.points,
//     required this.faceWidth,
//     required this.faceHeight,
//     required this.currentStrip,
//     required this.totalStrips,
//     required this.currentY,
//     required this.stripWidthPx,
//     required this.stripDirectionCounts,
//     required this.upCount,
//     required this.downCount,
//     required this.botImage,
//   });

//   @override
//   void paint(Canvas canvas, Size size) {
//     final safeWidth = faceWidth > 0 ? faceWidth : 1.0;
//     final safeHeight = faceHeight > 0 ? faceHeight : 1.0;

//     // Scale X physical meters to pixel width of the canvas
//     final scaleX = size.width / safeWidth;
//     final scaleY = size.height / safeHeight;

//     final glassRect = Rect.fromLTWH(0, 0, size.width, size.height);
//     canvas.drawRect(
//       glassRect,
//       Paint()
//         ..color = AppTheme.cyan.withOpacity(0.05)
//         ..style = PaintingStyle.fill,
//     );
//     canvas.drawRect(
//       glassRect,
//       Paint()
//         ..color = AppTheme.cyan.withOpacity(0.3)
//         ..strokeWidth = 1.0
//         ..style = PaintingStyle.stroke,
//     );

//     for (int i = 0; i < totalStrips; i++) {
//       final stripLeft = i * stripWidthPx;
//       if (i < currentStrip) {
//         canvas.drawRect(
//           Rect.fromLTWH(stripLeft, 0, stripWidthPx, size.height),
//           Paint()
//             ..color = AppTheme.cyan.withOpacity(0.35)
//             ..style = PaintingStyle.fill,
//         );
//       } else if (i == currentStrip) {
//         final cleanedFraction = currentY / safeHeight;
//         final cleanedHeightPx = cleanedFraction * size.height;
//         // Paint from TOP (0) to currentY
//         canvas.drawRect(
//           Rect.fromLTWH(stripLeft, 0, stripWidthPx, cleanedHeightPx),
//           Paint()
//             ..color = AppTheme.cyan.withOpacity(0.2)
//             ..style = PaintingStyle.fill,
//         );
//         canvas.drawLine(
//           Offset(stripLeft, cleanedHeightPx),
//           Offset(stripLeft + stripWidthPx, cleanedHeightPx),
//           Paint()
//             ..color = AppTheme.cyan.withOpacity(0.9)
//             ..strokeWidth = 2.0,
//         );
//       }
//       canvas.drawLine(
//         Offset(stripLeft, 0),
//         Offset(stripLeft, size.height),
//         Paint()
//           ..color = AppTheme.cyan.withOpacity(0.15)
//           ..strokeWidth = 0.5,
//       );
//     }

//     for (int i = 0; i <= currentStrip; i++) {
//       final double stripLeft = i * stripWidthPx;
//       final double cx = stripLeft + stripWidthPx / 2;
//       final up = i == currentStrip
//           ? upCount
//           : (stripDirectionCounts[i]?['up'] ?? 0);
//       final down = i == currentStrip
//           ? downCount
//           : (stripDirectionCounts[i]?['down'] ?? 0);

//       final double dynFont = (stripWidthPx * 0.3).clamp(9.0, 16.0);

//       canvas.save();
//       canvas.clipRect(Rect.fromLTWH(stripLeft, 0, stripWidthPx, size.height));

//       final tp1 = TextPainter(
//         text: TextSpan(
//           text: '↑$up',
//           style: TextStyle(
//             color: const Color(0xFF1ABECC),
//             fontSize: dynFont,
//             fontWeight: FontWeight.bold,
//           ),
//         ),
//         textDirection: TextDirection.ltr,
//         textAlign: TextAlign.center,
//       )..layout(maxWidth: stripWidthPx);
//       tp1.paint(canvas, Offset(cx - tp1.width / 2, 4));

//       final tp2 = TextPainter(
//         text: TextSpan(
//           text: '↓$down',
//           style: TextStyle(
//             color: const Color(0xFFD85A30),
//             fontSize: dynFont,
//             fontWeight: FontWeight.bold,
//           ),
//         ),
//         textDirection: TextDirection.ltr,
//         textAlign: TextAlign.center,
//       )..layout(maxWidth: stripWidthPx);
//       tp2.paint(
//         canvas,
//         Offset(cx - tp2.width / 2, size.height - tp2.height - 4),
//       );

//       canvas.restore();
//     }

//     if (points.isEmpty) return;

//     final pathPaint = Paint()
//       ..color = AppTheme.cyan
//       ..strokeWidth = 2.0
//       ..strokeCap = StrokeCap.round
//       ..style = PaintingStyle.stroke;
//     final robotTrail = Path();
//     robotTrail.moveTo(points.first.dx * scaleX, points.first.dy * scaleY);
//     for (int i = 1; i < points.length; i++) {
//       robotTrail.lineTo(points[i].dx * scaleX, points[i].dy * scaleY);
//     }
//     canvas.drawPath(robotTrail, pathPaint);

//     final lastScaledX = points.last.dx * scaleX;
//     final lastScaledY = points.last.dy * scaleY;
//     canvas.drawCircle(
//       Offset(lastScaledX, lastScaledY),
//       20.0,
//       Paint()..color = AppTheme.amber.withOpacity(0.2),
//     );

//     if (botImage != null) {
//       final src = Rect.fromLTWH(
//         0,
//         0,
//         botImage!.width.toDouble(),
//         botImage!.height.toDouble(),
//       );
//       final double robotWidth = min(
//         stripWidthPx * 0.75,
//         size.width * 0.1,
//       ).clamp(18.0, 38.0);
//       final double robotHeight = robotWidth * 1.75;
//       final dst = Rect.fromCenter(
//         center: Offset(lastScaledX, lastScaledY),
//         width: robotWidth,
//         height: robotHeight,
//       );
//       canvas.drawImageRect(botImage!, src, dst, Paint());
//     }
//   }

//   @override
//   bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
// }

// class _FaceInputButton extends StatefulWidget {
//   final String faceName;
//   final int currentFace;
//   final int totalFaces;
//   final double faceProgress;
//   final double faceWidth;
//   final double faceHeight;
//   final Function(double, double) onDimensionsChanged;
//   final VoidCallback onNextFace;
//   final VoidCallback onPrevFace;

//   const _FaceInputButton({
//     required this.faceName,
//     required this.currentFace,
//     required this.totalFaces,
//     required this.faceProgress,
//     required this.faceWidth,
//     required this.faceHeight,
//     required this.onDimensionsChanged,
//     required this.onNextFace,
//     required this.onPrevFace,
//   });

//   @override
//   State<_FaceInputButton> createState() => _FaceInputButtonState();
// }

// class _FaceInputButtonState extends State<_FaceInputButton> {
//   bool _open = false;
//   late TextEditingController _wCtrl;
//   late TextEditingController _hCtrl;
//   OverlayEntry? _overlay;
//   final _layerLink = LayerLink();

//   @override
//   void initState() {
//     super.initState();
//     _wCtrl = TextEditingController(text: widget.faceWidth.toStringAsFixed(1));
//     _hCtrl = TextEditingController(text: widget.faceHeight.toStringAsFixed(1));
//   }

//   void _toggleOverlay() {
//     if (_open) {
//       _overlay?.remove();
//       _overlay = null;
//       setState(() => _open = false);
//     } else {
//       _wCtrl.text = widget.faceWidth.toStringAsFixed(1);
//       _hCtrl.text = widget.faceHeight.toStringAsFixed(1);

//       _overlay = OverlayEntry(
//         builder: (_) => CompositedTransformFollower(
//           link: _layerLink,
//           showWhenUnlinked: false,
//           offset: const Offset(0, 34),
//           child: Align(
//             alignment: Alignment.topLeft,
//             child: Material(
//               color: Colors.transparent,
//               child: Container(
//                 width: 260,
//                 padding: const EdgeInsets.all(12),
//                 decoration: BoxDecoration(
//                   color: AppTheme.bgCard,
//                   borderRadius: BorderRadius.circular(8),
//                   border: Border.all(color: AppTheme.cyan.withOpacity(0.4)),
//                 ),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   mainAxisSize: MainAxisSize.min,
//                   children: [
//                     Text(
//                       'FACE DIMENSIONS',
//                       style: GoogleFonts.jetBrainsMono(
//                         fontSize: 9,
//                         color: AppTheme.textMid,
//                         letterSpacing: 1.2,
//                       ),
//                     ),
//                     const SizedBox(height: 10),
//                     Row(
//                       children: [
//                         Expanded(
//                           child: ElevatedButton(
//                             style: ElevatedButton.styleFrom(
//                               backgroundColor: AppTheme.amber.withOpacity(0.2),
//                               foregroundColor: AppTheme.amber,
//                               side: BorderSide(color: AppTheme.amber),
//                             ),
//                             onPressed: () {
//                               _overlay?.remove();
//                               _overlay = null;
//                               setState(() => _open = false);
//                               widget.onPrevFace();
//                             },
//                             child: Text(
//                               'PREV FACE',
//                               style: GoogleFonts.jetBrainsMono(
//                                 fontWeight: FontWeight.bold,
//                                 fontSize: 11,
//                               ),
//                             ),
//                           ),
//                         ),
//                         const SizedBox(width: 8),
//                         Expanded(
//                           child: ElevatedButton(
//                             style: ElevatedButton.styleFrom(
//                               backgroundColor: AppTheme.cyan.withOpacity(0.2),
//                               foregroundColor: AppTheme.cyan,
//                               side: BorderSide(color: AppTheme.cyan),
//                             ),
//                             onPressed: () {
//                               _overlay?.remove();
//                               _overlay = null;
//                               setState(() => _open = false);
//                               widget.onNextFace();
//                             },
//                             child: Text(
//                               'NEXT FACE',
//                               style: GoogleFonts.jetBrainsMono(
//                                 fontWeight: FontWeight.bold,
//                                 fontSize: 11,
//                               ),
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                     const SizedBox(height: 10),
//                     Row(
//                       children: [
//                         Expanded(
//                           child: _DimField(
//                             label: 'WIDTH (m)',
//                             controller: _wCtrl,
//                           ),
//                         ),
//                         const SizedBox(width: 8),
//                         Expanded(
//                           child: _DimField(
//                             label: 'HEIGHT (m)',
//                             controller: _hCtrl,
//                           ),
//                         ),
//                       ],
//                     ),
//                     const SizedBox(height: 10),
//                     SizedBox(
//                       width: double.infinity,
//                       child: ElevatedButton(
//                         style: ElevatedButton.styleFrom(
//                           backgroundColor: AppTheme.cyan.withOpacity(0.2),
//                           foregroundColor: AppTheme.cyan,
//                           side: BorderSide(color: AppTheme.cyan),
//                           padding: const EdgeInsets.symmetric(vertical: 8),
//                         ),
//                         onPressed: () {
//                           final w = double.tryParse(_wCtrl.text);
//                           final h = double.tryParse(_hCtrl.text);
//                           if (w != null && w > 0 && h != null && h > 0) {
//                             widget.onDimensionsChanged(w, h);
//                           }
//                           _overlay?.remove();
//                           _overlay = null;
//                           setState(() => _open = false);
//                         },
//                         child: Text(
//                           'APPLY DIMENSIONS',
//                           style: GoogleFonts.jetBrainsMono(
//                             fontWeight: FontWeight.bold,
//                             fontSize: 11,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ),
//         ),
//       );
//       Overlay.of(context).insert(_overlay!);
//       setState(() => _open = true);
//     }
//   }

//   @override
//   void dispose() {
//     _overlay?.remove();
//     _wCtrl.dispose();
//     _hCtrl.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final pct = widget.faceProgress.clamp(0.0, 100.0);

//     return CompositedTransformTarget(
//       link: _layerLink,
//       child: GestureDetector(
//         onTap: _toggleOverlay,
//         child: Stack(
//           children: [
//             Positioned.fill(
//               child: ClipRRect(
//                 borderRadius: BorderRadius.circular(6),
//                 child: FractionallySizedBox(
//                   alignment: Alignment.centerLeft,
//                   widthFactor: pct / 100,
//                   child: Container(color: AppTheme.cyan.withOpacity(0.18)),
//                 ),
//               ),
//             ),
//             Container(
//               padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
//               decoration: BoxDecoration(
//                 color: AppTheme.cyan.withOpacity(_open ? 0.25 : 0.15),
//                 borderRadius: BorderRadius.circular(6),
//                 border: Border.all(color: AppTheme.cyan),
//               ),
//               child: Row(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Text(
//                     '${widget.faceName}  (${widget.currentFace}/${widget.totalFaces})',
//                     style: GoogleFonts.jetBrainsMono(
//                       fontSize: 11,
//                       fontWeight: FontWeight.bold,
//                       color: AppTheme.cyan,
//                     ),
//                   ),
//                   const SizedBox(width: 6),
//                   Text(
//                     '${pct.toStringAsFixed(0)}%',
//                     style: GoogleFonts.jetBrainsMono(
//                       fontSize: 11,
//                       fontWeight: FontWeight.w700,
//                       color: AppTheme.cyan.withOpacity(0.8),
//                     ),
//                   ),
//                   const SizedBox(width: 4),
//                   Icon(
//                     _open ? Icons.expand_less : Icons.expand_more,
//                     size: 14,
//                     color: AppTheme.cyan,
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// class _DimField extends StatelessWidget {
//   final String label;
//   final TextEditingController controller;
//   const _DimField({required this.label, required this.controller});

//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Text(
//           label,
//           style: GoogleFonts.jetBrainsMono(
//             fontSize: 8,
//             color: AppTheme.textMid,
//             letterSpacing: 0.8,
//           ),
//         ),
//         const SizedBox(height: 4),
//         TextField(
//           controller: controller,
//           keyboardType: const TextInputType.numberWithOptions(decimal: true),
//           style: GoogleFonts.jetBrainsMono(
//             fontSize: 13,
//             color: AppTheme.textHi,
//           ),
//           decoration: InputDecoration(
//             isDense: true,
//             hintText: '0.0',
//             hintStyle: GoogleFonts.jetBrainsMono(
//               fontSize: 13,
//               color: AppTheme.textLo,
//             ),
//             contentPadding: const EdgeInsets.symmetric(
//               horizontal: 8,
//               vertical: 6,
//             ),
//             enabledBorder: OutlineInputBorder(
//               borderRadius: BorderRadius.circular(4),
//               borderSide: BorderSide(color: AppTheme.borderDim),
//             ),
//             focusedBorder: OutlineInputBorder(
//               borderRadius: BorderRadius.circular(4),
//               borderSide: BorderSide(color: AppTheme.cyan),
//             ),
//             filled: true,
//             fillColor: AppTheme.bg,
//           ),
//         ),
//       ],
//     );
//   }
// }

// class _ConfigTab extends StatelessWidget {
//   final Task task;
//   final VoidCallback onTaskUpdated;

//   const _ConfigTab({required this.task, required this.onTaskUpdated});

//   Future<void> _editCameraLink(
//     BuildContext context,
//     String cameraName,
//     String currentLink,
//     Function(String) onSave,
//   ) async {
//     final ctrl = TextEditingController(text: currentLink);
//     await showDialog(
//       context: context,
//       builder: (ctx) => AlertDialog(
//         backgroundColor: AppTheme.bgPanel,
//         title: Text(
//           'Edit $cameraName Link',
//           style: GoogleFonts.barlowCondensed(
//             fontSize: 18,
//             fontWeight: FontWeight.w700,
//             color: AppTheme.textHi,
//           ),
//         ),
//         content: GcsTextField(
//           controller: ctrl,
//           label: 'RTSP URL',
//           hint: 'rtsp://...',
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(ctx),
//             child: Text(
//               'CANCEL',
//               style: GoogleFonts.jetBrainsMono(
//                 fontSize: 11,
//                 color: AppTheme.textMid,
//               ),
//             ),
//           ),
//           TextButton(
//             onPressed: () {
//               onSave(ctrl.text.trim());
//               Navigator.pop(ctx);
//             },
//             child: Text(
//               'SAVE',
//               style: GoogleFonts.jetBrainsMono(
//                 fontSize: 11,
//                 fontWeight: FontWeight.w700,
//                 color: AppTheme.cyan,
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     final pad = AppTheme.screenPad(context);
//     return SingleChildScrollView(
//       padding: EdgeInsets.symmetric(horizontal: pad, vertical: 16),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           GcsSectionLabel('Task Details'),
//           const SizedBox(height: 12),
//           GcsCard(
//             child: Column(
//               children: [
//                 _CfgRow('Building', task.buildingName ?? ''),
//                 Divider(color: AppTheme.borderDim, height: 20),
//                 _CfgRow('Height', '${task.buildingHeight} m'),
//                 Divider(color: AppTheme.borderDim, height: 20),
//                 _CfgRow('Approx. Surface area', '${task.surfaceArea} m²'),
//                 Divider(color: AppTheme.borderDim, height: 20),
//                 _CfgRow('Device ID', task.deviceId ?? ''),
//               ],
//             ),
//           ),
//           const SizedBox(height: 20),
//           GcsSectionLabel('Data & Hardware Connections'),
//           const SizedBox(height: 12),
//           GcsCard(
//             child: Column(
//               children: [
//                 _CfgRow(
//                   'Camera A Link',
//                   (task.cameraALink?.isEmpty ?? true)
//                       ? 'Not Set'
//                       : task.cameraALink!,
//                   isEditable: true,
//                   onEdit: () => _editCameraLink(
//                     context,
//                     'Camera A',
//                     task.cameraALink ?? '',
//                     (newVal) async {
//                       task.cameraALink = newVal;
//                       await IsarService.updateTask(task);
//                       onTaskUpdated();
//                     },
//                   ),
//                 ),
//                 Divider(color: AppTheme.borderDim, height: 20),
//                 _CfgRow(
//                   'Camera B Link',
//                   (task.cameraBLink?.isEmpty ?? true)
//                       ? 'Not Set'
//                       : task.cameraBLink!,
//                   isEditable: true,
//                   onEdit: () => _editCameraLink(
//                     context,
//                     'Camera B',
//                     task.cameraBLink ?? '',
//                     (newVal) async {
//                       task.cameraBLink = newVal;
//                       await IsarService.updateTask(task);
//                       onTaskUpdated();
//                     },
//                   ),
//                 ),
//                 Divider(color: AppTheme.borderDim, height: 20),
//                 const _CfgRow('Telemetry', 'MANUAL SELECTION'),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// class _CfgRow extends StatelessWidget {
//   final String label, value;
//   final bool isEditable;
//   final VoidCallback? onEdit;

//   const _CfgRow(this.label, this.value, {this.isEditable = false, this.onEdit});

//   @override
//   Widget build(BuildContext context) {
//     return Row(
//       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       children: [
//         Text(
//           label,
//           style: GoogleFonts.jetBrainsMono(
//             fontSize: 11,
//             color: AppTheme.textMid,
//           ),
//         ),
//         const SizedBox(width: 16),
//         Expanded(
//           child: GestureDetector(
//             onTap: isEditable ? onEdit : null,
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.end,
//               children: [
//                 Flexible(
//                   child: Text(
//                     value,
//                     textAlign: TextAlign.right,
//                     overflow: TextOverflow.ellipsis,
//                     style: GoogleFonts.barlowCondensed(
//                       fontSize: 14,
//                       fontWeight: FontWeight.w600,
//                       color: isEditable ? AppTheme.cyan : AppTheme.textHi,
//                     ),
//                   ),
//                 ),
//                 if (isEditable) ...[
//                   const SizedBox(width: 8),
//                   Icon(Icons.edit_rounded, size: 14, color: AppTheme.cyan),
//                 ],
//               ],
//             ),
//           ),
//         ),
//       ],
//     );
//   }
// }

// class _SnapsTab extends StatefulWidget {
//   final Task task;
//   const _SnapsTab({required this.task});

//   @override
//   State<_SnapsTab> createState() => _SnapsTabState();
// }

// class _SnapsTabState extends State<_SnapsTab> {
//   @override
//   Widget build(BuildContext context) {
//     if (widget.task.snapshots.isEmpty) {
//       return const Center(child: Text("No snapshots yet."));
//     }

//     return GridView.builder(
//       padding: const EdgeInsets.all(16),
//       gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//         crossAxisCount: 4,
//         crossAxisSpacing: 10,
//         mainAxisSpacing: 10,
//       ),
//       itemCount: widget.task.snapshots.length,
//       itemBuilder: (context, index) {
//         final snap = widget.task.snapshots[index];
//         return GestureDetector(
//           onTap: () {
//             showGeneralDialog(
//               context: context,
//               barrierColor: Colors.black.withOpacity(0.95),
//               barrierDismissible: true,
//               barrierLabel: 'SnapViewer',
//               pageBuilder: (ctx, _, __) => _SnapshotViewer(
//                 snap: snap,
//                 task: widget.task,
//                 onUpdate: () => setState(() {}),
//               ),
//             );
//           },
//           child: ClipRRect(
//             borderRadius: BorderRadius.circular(8),
//             child: Stack(
//               fit: StackFit.expand,
//               children: [
//                 Image.file(File(snap.filePath!), fit: BoxFit.cover),
//                 Positioned(
//                   bottom: 0,
//                   left: 0,
//                   right: 0,
//                   child: Container(
//                     color: Colors.black54,
//                     padding: const EdgeInsets.all(4),
//                     child: Text(
//                       '${snap.cameraName}',
//                       style: const TextStyle(color: Colors.white, fontSize: 9),
//                       textAlign: TextAlign.center,
//                       maxLines: 1,
//                       overflow: TextOverflow.ellipsis,
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }
// }

// class _SnapshotViewer extends StatefulWidget {
//   final TaskSnapshot snap;
//   final Task task;
//   final VoidCallback onUpdate;

//   const _SnapshotViewer({
//     required this.snap,
//     required this.task,
//     required this.onUpdate,
//   });

//   @override
//   State<_SnapshotViewer> createState() => _SnapshotViewerState();
// }

// class _SnapshotViewerState extends State<_SnapshotViewer> {
//   bool _showInfo = false;

//   void _editName() {
//     final ctrl = TextEditingController(text: widget.snap.cameraName);
//     showDialog(
//       context: context,
//       builder: (ctx) => AlertDialog(
//         backgroundColor: AppTheme.bgPanel,
//         title: Text('Edit Name', style: TextStyle(color: AppTheme.textHi)),
//         content: TextField(
//           controller: ctrl,
//           style: TextStyle(color: AppTheme.textHi),
//           decoration: const InputDecoration(hintText: "Enter new name"),
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(ctx),
//             child: const Text('CANCEL'),
//           ),
//           TextButton(
//             onPressed: () async {
//               setState(() {
//                 widget.snap.cameraName = ctrl.text.trim();
//                 widget.task.isSynced = false;
//               });
//               await IsarService.updateTask(widget.task);
//               widget.onUpdate();
//               Navigator.pop(ctx);
//             },
//             child: Text('SAVE', style: TextStyle(color: AppTheme.cyan)),
//           ),
//         ],
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     File imgFile = File(widget.snap.filePath!);
//     String fileName = imgFile.path.split('/').last;

//     return SafeArea(
//       child: Scaffold(
//         backgroundColor: Colors.transparent,
//         body: Stack(
//           children: [
//             Center(
//               child: InteractiveViewer(
//                 minScale: 0.5,
//                 maxScale: 4.0,
//                 child: Image.file(imgFile),
//               ),
//             ),
//             Positioned(
//               top: 16,
//               right: 16,
//               child: IconButton(
//                 icon: const Icon(
//                   Icons.close_rounded,
//                   color: Colors.white,
//                   size: 32,
//                 ),
//                 onPressed: () => Navigator.pop(context),
//               ),
//             ),
//             if (_showInfo)
//               Positioned(
//                 bottom: 90,
//                 left: 20,
//                 right: 20,
//                 child: Container(
//                   padding: const EdgeInsets.all(16),
//                   decoration: BoxDecoration(
//                     color: Colors.black.withOpacity(0.65),
//                     borderRadius: BorderRadius.circular(12),
//                     border: Border.all(color: Colors.white24),
//                   ),
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       Text(
//                         'FILE INFO',
//                         style: GoogleFonts.jetBrainsMono(
//                           color: AppTheme.cyan,
//                           fontWeight: FontWeight.bold,
//                           fontSize: 12,
//                         ),
//                       ),
//                       const SizedBox(height: 8),
//                       Text(
//                         'Name:     $fileName',
//                         style: const TextStyle(
//                           color: Colors.white,
//                           fontSize: 11,
//                         ),
//                       ),
//                       Text(
//                         'Created:  ${widget.snap.timestamp.toString().split('.')[0]}',
//                         style: const TextStyle(
//                           color: Colors.white,
//                           fontSize: 11,
//                         ),
//                       ),
//                       const Text(
//                         'Location: No Info',
//                         style: TextStyle(color: Colors.white, fontSize: 11),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             Positioned(
//               bottom: 20,
//               left: 0,
//               right: 0,
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   _actionBtn(
//                     Icons.info_outline,
//                     "Info",
//                     () => setState(() => _showInfo = !_showInfo),
//                   ),
//                   const SizedBox(width: 20),
//                   _actionBtn(Icons.edit_rounded, "Edit", _editName),
//                   const SizedBox(width: 20),
//                   _actionBtn(Icons.share_rounded, "Share", () {
//                     Share.shareXFiles([
//                       XFile(imgFile.path),
//                     ], text: 'Wiperque Snapshot: ${widget.snap.cameraName}');
//                   }),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _actionBtn(IconData icon, String label, VoidCallback onTap) {
//     return GestureDetector(
//       onTap: onTap,
//       child: Column(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           Container(
//             padding: const EdgeInsets.all(12),
//             decoration: const BoxDecoration(
//               color: Colors.black54,
//               shape: BoxShape.circle,
//             ),
//             child: Icon(icon, color: Colors.white, size: 24),
//           ),
//           const SizedBox(height: 4),
//           Text(
//             label,
//             style: const TextStyle(color: Colors.white, fontSize: 10),
//           ),
//         ],
//       ),
//     );
//   }
// }

// class _VideosTab extends StatelessWidget {
//   final Task task;
//   const _VideosTab({required this.task});

//   @override
//   Widget build(BuildContext context) {
//     if (task.videos.isEmpty) {
//       return const Center(child: Text("No recorded videos."));
//     }

//     final validVideos = task.videos
//         .where(
//           (v) =>
//               v.filePath != null &&
//               File(v.filePath!).existsSync() &&
//               File(v.filePath!).lengthSync() > 0,
//         )
//         .toList();

//     return ListView.builder(
//       padding: const EdgeInsets.all(16),
//       itemCount: task.videos.length,
//       itemBuilder: (ctx, i) {
//         final video = task.videos[i];
//         final fileName = video.filePath?.split('/').last ?? 'Unknown';
//         final bool isValidFile = validVideos.contains(video);

//         return Card(
//           color: AppTheme.bgCard,
//           margin: const EdgeInsets.only(bottom: 8),
//           child: ListTile(
//             contentPadding: const EdgeInsets.symmetric(
//               horizontal: 12,
//               vertical: 8,
//             ),
//             leading: SizedBox(
//               width: 60,
//               height: 60,
//               child: ClipRRect(
//                 borderRadius: BorderRadius.circular(6),
//                 child: isValidFile
//                     ? _VideoThumbnail(videoPath: video.filePath!)
//                     : Container(
//                         color: AppTheme.bgPanel,
//                         child: Icon(
//                           Icons.broken_image_rounded,
//                           color: AppTheme.textLo,
//                           size: 24,
//                         ),
//                       ),
//               ),
//             ),
//             title: Text(
//               video.cameraName ?? 'Video Record',
//               style: TextStyle(
//                 color: isValidFile ? AppTheme.textHi : AppTheme.textLo,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             subtitle: Text(
//               '${video.timestamp.toString().split('.')[0]}\n$fileName',
//               style: TextStyle(color: AppTheme.textLo, fontSize: 11),
//             ),
//             trailing: IconButton(
//               icon: Icon(
//                 Icons.share_rounded,
//                 color: isValidFile ? AppTheme.cyan : AppTheme.borderDim,
//               ),
//               onPressed: () async {
//                 if (isValidFile) {
//                   await Share.shareXFiles([
//                     XFile(video.filePath!),
//                   ], text: 'Recorded Stream');
//                 } else {
//                   ScaffoldMessenger.of(context).showSnackBar(
//                     const SnackBar(content: Text('File corrupted or missing.')),
//                   );
//                 }
//               },
//             ),
//             onTap: () {
//               if (isValidFile) {
//                 final initialIndex = validVideos.indexOf(video);
//                 showGeneralDialog(
//                   context: context,
//                   barrierColor: Colors.black.withOpacity(0.95),
//                   barrierDismissible: true,
//                   barrierLabel: 'VideoViewer',
//                   pageBuilder: (ctx, _, __) => _VideoViewer(
//                     videos: validVideos,
//                     initialIndex: initialIndex,
//                   ),
//                 );
//               }
//             },
//           ),
//         );
//       },
//     );
//   }
// }

// class _VideoThumbnail extends StatefulWidget {
//   final String videoPath;
//   const _VideoThumbnail({required this.videoPath});
//   @override
//   State<_VideoThumbnail> createState() => _VideoThumbnailState();
// }

// class _VideoThumbnailState extends State<_VideoThumbnail> {
//   Uint8List? _thumbData;
//   @override
//   void initState() {
//     super.initState();
//     _generateThumbnail();
//   }

//   Future<void> _generateThumbnail() async {
//     try {
//       final uint8list = await VideoThumbnail.thumbnailData(
//         video: widget.videoPath,
//         imageFormat: ImageFormat.JPEG,
//         maxWidth: 150,
//         quality: 50,
//       );
//       if (mounted) setState(() => _thumbData = uint8list);
//     } catch (e) {
//       debugPrint("Thumbnail error: $e");
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     if (_thumbData == null) {
//       return Container(
//         color: Colors.black45,
//         child: const Center(child: CircularProgressIndicator(strokeWidth: 2)),
//       );
//     }
//     return Stack(
//       fit: StackFit.expand,
//       children: [
//         Image.memory(_thumbData!, fit: BoxFit.cover),
//         Container(color: Colors.black26),
//         const Center(
//           child: Icon(
//             Icons.play_circle_fill_rounded,
//             color: Colors.white,
//             size: 24,
//           ),
//         ),
//       ],
//     );
//   }
// }

// class _VideoViewer extends StatefulWidget {
//   final List<TaskVideo> videos;
//   final int initialIndex;

//   const _VideoViewer({required this.videos, required this.initialIndex});

//   @override
//   State<_VideoViewer> createState() => _VideoViewerState();
// }

// class _VideoViewerState extends State<_VideoViewer> {
//   late final Player player;
//   late final VideoController controller;
//   late int currentIndex;

//   bool _showControls = true;
//   bool _isPlaying = true;
//   Timer? _hideControlsTimer;

//   BoxFit _currentFit = BoxFit.contain;
//   final TransformationController _zoomCtrl = TransformationController();

//   final List<double> _speeds = [1.0, 2.0, 4.0, 6.0, 8.0, 10.0];
//   int _speedIndex = 0;

//   int _seekAccumulator = 0;
//   Timer? _seekOverlayTimer;

//   @override
//   void initState() {
//     super.initState();
//     currentIndex = widget.initialIndex;
//     player = Player();
//     controller = VideoController(player);
//     _loadVideo(currentIndex);
//     _startControlsTimer();

//     player.stream.playing.listen((playing) {
//       if (mounted) setState(() => _isPlaying = playing);
//     });
//   }

//   void _loadVideo(int index) {
//     final path = widget.videos[index].filePath;
//     if (path != null) {
//       player.open(Media(path), play: true);
//       setState(() {
//         _speedIndex = 0;
//         player.setRate(1.0);
//       });
//     }
//   }

//   void _nextVideo() {
//     if (currentIndex < widget.videos.length - 1) {
//       setState(() => currentIndex++);
//       _loadVideo(currentIndex);
//     }
//   }

//   void _prevVideo() {
//     if (currentIndex > 0) {
//       setState(() => currentIndex--);
//       _loadVideo(currentIndex);
//     }
//   }

//   void _cycleSpeed() {
//     setState(() {
//       _speedIndex = (_speedIndex + 1) % _speeds.length;
//       player.setRate(_speeds[_speedIndex]);
//     });
//   }

//   void _togglePlay() {
//     _isPlaying ? player.pause() : player.play();
//     _resetControlsTimer();
//   }

//   void _toggleControls() {
//     setState(() => _showControls = !_showControls);
//     if (_showControls) _startControlsTimer();
//   }

//   void _startControlsTimer() {
//     _hideControlsTimer?.cancel();
//     _hideControlsTimer = Timer(const Duration(seconds: 4), () {
//       if (mounted && _isPlaying) setState(() => _showControls = false);
//     });
//   }

//   void _resetControlsTimer() {
//     if (_showControls) _startControlsTimer();
//   }

//   void _handleDoubleTapSeek(bool isForward) {
//     final step = const Duration(seconds: 10);
//     setState(() {
//       _seekAccumulator += isForward ? 10 : -10;
//     });

//     final currentPos = player.state.position;
//     player.seek(currentPos + (isForward ? step : -step));

//     _seekOverlayTimer?.cancel();
//     _seekOverlayTimer = Timer(const Duration(milliseconds: 1000), () {
//       if (mounted) setState(() => _seekAccumulator = 0);
//     });
//   }

//   @override
//   void dispose() {
//     _hideControlsTimer?.cancel();
//     _seekOverlayTimer?.cancel();
//     _zoomCtrl.dispose();
//     player.dispose();
//     super.dispose();
//   }

//   String _formatDuration(Duration d) {
//     String twoDigits(int n) => n.toString().padLeft(2, '0');
//     final m = twoDigits(d.inMinutes.remainder(60));
//     final s = twoDigits(d.inSeconds.remainder(60));
//     if (d.inHours > 0) return '${d.inHours}:$m:$s';
//     return '$m:$s';
//   }

//   @override
//   Widget build(BuildContext context) {
//     final fileName =
//         widget.videos[currentIndex].filePath?.split('/').last ?? '';

//     return SafeArea(
//       child: Scaffold(
//         backgroundColor: Colors.transparent,
//         body: Stack(
//           fit: StackFit.expand,
//           children: [
//             Center(
//               child: AspectRatio(
//                 aspectRatio: 16 / 9,
//                 child: InteractiveViewer(
//                   transformationController: _zoomCtrl,
//                   minScale: 1.0,
//                   maxScale: 20.0,
//                   child: Video(
//                     controller: controller,
//                     fit: _currentFit,
//                     controls: NoVideoControls,
//                   ),
//                 ),
//               ),
//             ),

//             Row(
//               children: [
//                 Expanded(
//                   child: GestureDetector(
//                     onTap: _toggleControls,
//                     onDoubleTap: () => _handleDoubleTapSeek(false),
//                     behavior: HitTestBehavior.translucent,
//                   ),
//                 ),
//                 Expanded(
//                   child: GestureDetector(
//                     onTap: _toggleControls,
//                     behavior: HitTestBehavior.translucent,
//                   ),
//                 ),
//                 Expanded(
//                   child: GestureDetector(
//                     onTap: _toggleControls,
//                     onDoubleTap: () => _handleDoubleTapSeek(true),
//                     behavior: HitTestBehavior.translucent,
//                   ),
//                 ),
//               ],
//             ),

//             if (_seekAccumulator != 0)
//               Center(
//                 child: Container(
//                   padding: const EdgeInsets.symmetric(
//                     horizontal: 24,
//                     vertical: 12,
//                   ),
//                   decoration: BoxDecoration(
//                     color: Colors.black54,
//                     borderRadius: BorderRadius.circular(30),
//                   ),
//                   child: Text(
//                     '${_seekAccumulator > 0 ? "+" : ""}${_seekAccumulator}s',
//                     style: const TextStyle(
//                       color: Colors.white,
//                       fontSize: 24,
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                 ),
//               ),

//             if (_showControls)
//               Container(
//                 color: Colors.black45,
//                 child: Stack(
//                   children: [
//                     Positioned(
//                       top: 16,
//                       left: 24,
//                       right: 16,
//                       child: Row(
//                         children: [
//                           Expanded(
//                             child: Text(
//                               fileName,
//                               style: GoogleFonts.jetBrainsMono(
//                                 color: AppTheme.cyan,
//                                 fontWeight: FontWeight.bold,
//                               ),
//                             ),
//                           ),
//                           TextButton(
//                             onPressed: () {
//                               _cycleSpeed();
//                               _resetControlsTimer();
//                             },
//                             child: Text(
//                               '${_speeds[_speedIndex].toInt()}x',
//                               style: const TextStyle(
//                                 color: Colors.white,
//                                 fontWeight: FontWeight.bold,
//                               ),
//                             ),
//                           ),
//                           PopupMenuButton<String>(
//                             icon: const Icon(
//                               Icons.more_vert_rounded,
//                               color: Colors.white,
//                             ),
//                             color: AppTheme.bgPanel,
//                             onSelected: (val) {
//                               _resetControlsTimer();
//                               if (val == 'fit')
//                                 setState(() => _currentFit = BoxFit.contain);
//                               if (val == 'fill')
//                                 setState(() => _currentFit = BoxFit.cover);
//                               if (val == 'stretch')
//                                 setState(() => _currentFit = BoxFit.fill);
//                               if (val == 'reset_zoom')
//                                 _zoomCtrl.value = Matrix4.identity();
//                             },
//                             itemBuilder: (ctx) => [
//                               const PopupMenuItem(
//                                 value: 'fit',
//                                 child: Text(
//                                   'Aspect: Fit',
//                                   style: TextStyle(color: Colors.white),
//                                 ),
//                               ),
//                               const PopupMenuItem(
//                                 value: 'fill',
//                                 child: Text(
//                                   'Aspect: Crop/Fill',
//                                   style: TextStyle(color: Colors.white),
//                                 ),
//                               ),
//                               const PopupMenuItem(
//                                 value: 'stretch',
//                                 child: Text(
//                                   'Aspect: Stretch',
//                                   style: TextStyle(color: Colors.white),
//                                 ),
//                               ),
//                               const PopupMenuDivider(),
//                               PopupMenuItem(
//                                 value: 'reset_zoom',
//                                 child: Text(
//                                   'Reset Zoom',
//                                   style: TextStyle(color: AppTheme.cyan),
//                                 ),
//                               ),
//                             ],
//                           ),
//                           IconButton(
//                             icon: const Icon(
//                               Icons.close_rounded,
//                               color: Colors.white,
//                               size: 32,
//                             ),
//                             onPressed: () => Navigator.pop(context),
//                           ),
//                         ],
//                       ),
//                     ),

//                     Center(
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         children: [
//                           IconButton(
//                             iconSize: 42,
//                             color: currentIndex > 0
//                                 ? Colors.white
//                                 : Colors.white30,
//                             icon: const Icon(Icons.skip_previous_rounded),
//                             onPressed: currentIndex > 0
//                                 ? () {
//                                     _prevVideo();
//                                     _resetControlsTimer();
//                                   }
//                                 : null,
//                           ),
//                           const SizedBox(width: 30),
//                           IconButton(
//                             iconSize: 42,
//                             color: Colors.white,
//                             icon: const Icon(Icons.replay_10_rounded),
//                             onPressed: () {
//                               _handleDoubleTapSeek(false);
//                               _resetControlsTimer();
//                             },
//                           ),
//                           const SizedBox(width: 30),
//                           GestureDetector(
//                             onTap: _togglePlay,
//                             child: Icon(
//                               _isPlaying
//                                   ? Icons.pause_circle_outline_rounded
//                                   : Icons.play_circle_outline_rounded,
//                               color: Colors.white,
//                               size: 80,
//                             ),
//                           ),
//                           const SizedBox(width: 30),
//                           IconButton(
//                             iconSize: 42,
//                             color: Colors.white,
//                             icon: const Icon(Icons.forward_10_rounded),
//                             onPressed: () {
//                               _handleDoubleTapSeek(true);
//                               _resetControlsTimer();
//                             },
//                           ),
//                           const SizedBox(width: 30),
//                           IconButton(
//                             iconSize: 42,
//                             color: currentIndex < widget.videos.length - 1
//                                 ? Colors.white
//                                 : Colors.white30,
//                             icon: const Icon(Icons.skip_next_rounded),
//                             onPressed: currentIndex < widget.videos.length - 1
//                                 ? () {
//                                     _nextVideo();
//                                     _resetControlsTimer();
//                                   }
//                                 : null,
//                           ),
//                         ],
//                       ),
//                     ),

//                     Positioned(
//                       bottom: 24,
//                       left: 24,
//                       right: 24,
//                       child: StreamBuilder<Duration>(
//                         stream: player.stream.position,
//                         builder: (context, snapshot) {
//                           final position = snapshot.data ?? Duration.zero;
//                           final duration = player.state.duration;
//                           return Row(
//                             children: [
//                               Text(
//                                 _formatDuration(position),
//                                 style: const TextStyle(color: Colors.white),
//                               ),
//                               Expanded(
//                                 child: SliderTheme(
//                                   data: SliderTheme.of(context).copyWith(
//                                     thumbColor: AppTheme.cyan,
//                                     activeTrackColor: AppTheme.cyan,
//                                     inactiveTrackColor: Colors.white30,
//                                   ),
//                                   child: Slider(
//                                     value: position.inMilliseconds
//                                         .toDouble()
//                                         .clamp(
//                                           0,
//                                           duration.inMilliseconds.toDouble(),
//                                         ),
//                                     max: duration.inMilliseconds > 0
//                                         ? duration.inMilliseconds.toDouble()
//                                         : 1.0,
//                                     onChanged: (val) {
//                                       player.seek(
//                                         Duration(milliseconds: val.toInt()),
//                                       );
//                                       _resetControlsTimer();
//                                     },
//                                   ),
//                                 ),
//                               ),
//                               Text(
//                                 _formatDuration(duration),
//                                 style: const TextStyle(color: Colors.white),
//                               ),
//                             ],
//                           );
//                         },
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// class _AlertsTab extends StatelessWidget {
//   final Task task;
//   const _AlertsTab({required this.task});

//   @override
//   Widget build(BuildContext context) {
//     return ListView.builder(
//       padding: const EdgeInsets.all(16),
//       itemCount: task.alerts.length,
//       itemBuilder: (ctx, i) {
//         final alert = task.alerts[i];
//         final isCritical = alert.type == 'CRITICAL';
//         return Card(
//           color: AppTheme.bgCard,
//           margin: const EdgeInsets.only(bottom: 8),
//           child: ListTile(
//             leading: Icon(
//               isCritical ? Icons.warning_rounded : Icons.info_outline,
//               color: isCritical ? AppTheme.red : AppTheme.amber,
//             ),
//             title: Text(
//               alert.message ?? 'Unknown Alert',
//               style: TextStyle(
//                 color: AppTheme.textHi,
//                 fontSize: 13,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             subtitle: Text(
//               alert.timestamp.toString().split('.')[0],
//               style: TextStyle(color: AppTheme.textLo, fontSize: 11),
//             ),
//           ),
//         );
//       },
//     );
//   }
// }
